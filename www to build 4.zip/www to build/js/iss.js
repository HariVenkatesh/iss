function getQueryParam( name ) {
  name = name.replace(/[\[]/,"\\\[").replace(/[\]]/,"\\\]");
  var regexS = "[\\?&]"+name+"=([^&#]*)";
  var regex = new RegExp( regexS );
  var results = regex.exec( window.location.href );
  if( results == null )
    return "";
  else
    return results[1];
}

Storage.prototype.setObject = function(key, value) {
  this.setItem(key, JSON.stringify(value));
};

Storage.prototype.getObject = function(key) {
  var value = this.getItem(key);
  if (value > "") {
    return value && JSON.parse(value);
  }

  return {};
}; // Storage.prototype.getObject

String.prototype.toTitleCase = function () { 
  var str = this;
  return str.replace(/\w\S*/g, function(txt){return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase();});
}; // String.prototype.toTitleCase

String.prototype.escape = function() {
  var text = this;
  if (text > "") {
    var map = {
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#039;'
    };

    return text.replace(/[&<>"']/g, function(m) { return map[m]; });
  }
  return "";
}

function getActivePage() {
  return $.mobile.pageContainer.pagecontainer( "getActivePage" );
}; // getActivePage


function scrollToTop(top) {
  if (top == undefined) { top = 0; };
  $("html, body").animate({ "scrollTop" : top }, 500); 
};

function yn(bValue) {
  if (bValue) { 
    return "Y";
  }
  return "N"; 
};

function ArrNoDupe(a) {
  var temp = {};
  for (var i = 0; i < a.length; i++)
    temp[a[i]] = true;
  var r = [];
  for (var k in temp)
    r.push(k);
  return r.reverse();
};

function dateTimeTZProgressRenderer(sDateTime) {
  try {
    var sDate = new Date(Date.parse(sDateTime)).format("progress", false);
    var token = sDate.split(" ");
    var newDate = token[0] + " " + token[1] + " " + token[2].substring(0, 3)
    + ":" + token[2].substring(3, 5);
    return newDate;
  } catch (e) {
    return "";
  }
};

function getCookie( check_name ) {
  // first we'll split this cookie up into name/value pairs
  // note: document.cookie only returns name=value, not the other components
  var a_all_cookies = document.cookie.split( ';' );
  var a_temp_cookie = '';
  var cookie_name = '';
  var cookie_value = '';
  var b_cookie_found = false; // set boolean t/f default f

  for ( i = 0; i < a_all_cookies.length; i++ )
  {
    // now we'll split apart each name=value pair
    a_temp_cookie = a_all_cookies[i].split( '=' );


    // and trim left/right whitespace while we're at it
    cookie_name = a_temp_cookie[0].replace(/^\s+|\s+$/g, '');

    // if the extracted name matches passed check_name
    if ( cookie_name == check_name )
    {
      b_cookie_found = true;
      // we need to handle case where cookie has no value but exists (no = sign, that is):
      if ( a_temp_cookie.length > 1 )
      {
        cookie_value = unescape( a_temp_cookie[1].replace(/^\s+|\s+$/g, '') );
      }
      // note that in cases where cookie is initialized but no value, null is returned
      return cookie_value;
      break;
    }
    a_temp_cookie = null;
    cookie_name = '';
  }
  if ( !b_cookie_found )
  {
    return null;
  }
}

function deleteCookie( name, path, domain ) {
  if ( getCookie( name ) ) document.cookie = name + "=" +
  ( ( path ) ? ";path=" + path : "") +
  ( ( domain ) ? ";domain=" + domain : "" ) +
  ";expires=Thu, 01-Jan-1970 00:00:01 GMT";
}

function logOff() {
  if (confirm("Are you sure you want to logoff?")) {
    deleteCookie("Password");
    document.location = myURL + "moblogoff.p?h_token=" + sToken;
    return true;
  }
  return false;
}

function setCookie( name, value, expires, path, domain, secure )
{
  // set time, it's in milliseconds
  var today = new Date();
  today.setTime( today.getTime() );

  /*
  if the expires variable is set, make the correct
  expires time, the current script below will set
  it for x number of days, to make it for hours,
  delete * 24, for minutes, delete * 60 * 24
   */
  /*if ( expires )
  {
  expires = expires * 1000 * 60 * 60 * 24;
  }*/

  var expires_date = new Date( today.getTime() + (expires) );

  document.cookie = name + "=" +escape( value ) +
  ( ( expires ) ? ";expires=" + expires_date.toGMTString() : "" ) +
  ( ( path ) ? ";path=" + path : "" ) +
  ( ( domain ) ? ";domain=" + domain : "" ) +
  ( ( secure ) ? ";secure" : "" ) ;
}

function dateTimeTZRenderer(sDateTime) {
  try { 
    return formatDate(new Date(Date.parse(sDateTime)));
  }      
  catch (e) { 
    return "";
  }
}

function formatDate(date) {

  if ( isNaN( date.getTime() ) ) { return ""};
  
  return date.toLocaleString();
  
  var hours = date.getHours();
  var minutes = date.getMinutes();
  var ampm = hours >= 12 ? 'pm' : 'am';
  hours = hours % 12;
  hours = hours ? hours : 12; // the hour '0' should be '12'
  minutes = minutes < 10 ? '0'+minutes : minutes;
  var strTime = hours + ':' + minutes + ' ' + ampm;
  return date.getMonth()+1 + "/" + date.getDate() + "/" + date.getFullYear() + "  " + strTime;
}

//plugins
jQuery.fn.scrollToTop = function(settings) {
  settings = jQuery.extend({
    min: 400
  }, settings);
  return this.each(function() {
    
    //listen for scroll
    var el = $(this);
    el.hide(); //in case the user forgot
    $(document).on("scroll",function(){
      if($(window).scrollTop() >= settings.min) {
        el.removeClass("ui-btn-active");
        el.show();
      }
      else {
        el.hide();
      };
    });
  });
};

$(function() {
  $(document).delegate('.iTabs a', 'vclick', function (e) {
      var tabs = $(this).parents(".iTabs");
      tabs.find('a').removeClass("ui-btn-active");
      $("#" + tabs.attr("data-content")).children().hide();
      $('#' + $(this).attr('data-tab')).show();
      //$("html,body").animate({scrollTop:0},500);
      $(this).addClass("ui-btn-active");
      e.preventDefault();
  });
  
  $(".iTabs").each(function() {
    var content = $("#" + $(this).attr("data-content"));
    content.children().hide();
    content.find('div:first').show();
  });
});

var showErrorMessage = function (msg){
  $("<div class='ui-loader ui-overlay-shadow ui-body-a ui-corner-all'><h3>" + msg + "</h3></div>")
  .css({display: "block", 
    opacity: 1, 
    position: "fixed",
    "background-color": "red",
    "color": "white",
    padding: "7px",
    "text-align": "center",
    width: "270px",
    left: ($(window).width() - 284)/2,
    top: $(window).height()/3 })
  .appendTo( $.mobile.pageContainer ).delay( 5000 )
  .fadeOut( 400, function(){
    $(this).remove();
  });
}; // showErrorMessage

var showWarningMessage = function (msg){
  $("<div class='ui-loader ui-overlay-shadow ui-body-a ui-corner-all'><h3>" + msg + "</h3></div>")
  .css({ display: "block", 
    opacity: 1, 
    position: "fixed",
    padding: "7px",
    "text-align": "center",
    "background-color": "yellow",
    width: "270px",
    left: ($(window).width() - 284)/2,
    top: $(window).height()/3 })
  .appendTo( $.mobile.pageContainer ).delay( 1500 )
  .fadeOut( 400, function(){
    $(this).remove();
  });
}; // showWarningMessage

