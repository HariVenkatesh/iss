var localData = {};
var i=0;
//  var myURL    = "http://demo.issgroup.net/efw50/ipurchase/mobile/index.html";//getQueryParam("myURL");
//  var sShowReq = "demo1";//getQueryParam("showReq");
//  var sDomain  = "demo1";//getQueryParam("showDomain");
//  var sToken   = "fjpaEYXriCHmXkHc000723418034470391bkGYbbbXrlaGWcblGibTllilfCajLmFgyiQBTlIUbdllpjbl";//getQueryParam("token");
  var myURL = "http://demo.issgroup.net/scripts/cgiip.exe/WService=iPurchase/";//getQueryParam("myURL");
  var sShowReq="";
  var sDomain= "";//selectedDomain;//"demo1";
  var sToken = "";//localStorage.getItem("Token");
//alert(sToken);
  var initData = {};
  var NUM_RECORDS = 10;
  var panelCounter = 0;
  var bDone = false;
  var SHOW_FIRST = "FIRST";
  var SHOW_NEXT  = "NEXT";
  var newURL;
  var currentReq = {};
  var $Panel = 
    $('<div data-role="panel" style="background-color: rgb(246,246,246);" class="menuPanel jqm-navmenu-panel" data-position="right" data-display="overlay">' +
      '  <ul class="jqm-list ui-alt-icon ui-nodisc-icon">' +
      '    <li data-role="list-divider"><p class="menuLabel">Menu</p></li>' +
      '    <li><a href="#homePage" class="ui-btn ui-btn-icon-left ui-icon-home">Home</a></li>' +
      '    <li><a href="#" class="pendingMyApproval ui-btn ui-btn-icon-left ui-icon-check">Pending My Approval</a></li>' +
      '    <li><a href="#" class="myRequisitions ui-btn ui-btn-icon-left ui-icon-user">My Requisitions</a></li>' +
      '    <li><a href="#viewSearchPage" class="searchLink ui-btn ui-btn-icon-left ui-icon-search">Requisition Inquiry</a></li>' +
      '    <li><a href="#viewPOSearchPage" class="searchPOLink ui-btn ui-btn-icon-left ui-icon-bullets">PO Inquiry</a></li>' +
    '    <li><a href="#viewPunchoutsPage" class="oofLink ui-btn ui-btn-b ui-btn-icon-left ui-alt-icon ui-icon-shop">Punchouts</a></li>' +
      '    <li><a href="#viewOOFPage" class="oofLink ui-btn ui-btn-icon-left ui-icon-forward">Out of Office</a></li>' +
      '    <li><a  href="#" onclick="logOff();" class="ui-btn ui-btn-icon-left ui-icon-power">Logoff</a></li>' +
      '  </ul>' +
      '</div>');

  var $Header = 
    $('<div style="padding-top:20px" data-role="header" data-position="fixed" class="jqm-header" >' +
    '<a xstyle="margin-top:20px" class="backBtn" data-rel="back" data-iconpos="notext" data-icon="back">Back</a>' +   
        '<a xstyle="margin-top:20px" href=" #leftpanel2" data-iconpos="notext" data-icon="grid">Menu</a>' +  
    '<h1>iPurchase Mobile</h1>' +
//    '<a style="padding-top:20px" href="#" class="menuLink jqm-navmenu-link" data-iconpos="notext" data-icon="bars"></a>' +
    '<div data-role="navbar" class="jqm-header-nav-bar" data-iconpos="top" style="width:100%;">' +
    ' <ul>' +
    '   <li><a href="" onclick="homePage_pushnotication();" data-iconpos="notext" data-icon="home"></a></li>' +
   '   <li><a href="#" class="pendingMyApproval" data-iconpos="notext" data-icon="check"></a></li>' +
    '   <li><a href="#" class="myRequisitions" data-iconpos="notext" data-icon="user"></a></li>' +
    '   <li><a href="#viewSearchPage" id="viewSearchPage" class="searchLink" data-iconpos="notext" data-icon="search"></a></li>' +
    '   <li><a href="#viewPOSearchPage" data-iconpos="notext" data-icon="bullets"></a></li>' + 
   // '   <li><a href="#viewPunchoutsPage" data-iconpos="notext" data-icon="shop" id="hPunchouts"></a></li>' +
    '   <li><a href="#viewOOFPage" class="oofLink" data-iconpos="notext" data-icon="forward" id="hOOF"></a></li>' +
    '   <li><a href="#" rel="external" onclick="return logOff();" data-iconpos="notext" data-icon="power"></a></li>' +
    ' </ul>' +
    '</div>' +
    '</div>');

  if(("standalone" in window.navigator) && window.navigator.standalone){
    $(".backBtn", $Header).css("margin-top", "20px");
    $Header.css("padding-top", "20px");
  }
  
  var footer = 
    '<div data-role="footer" data-position="fixed" data-id:"footer" class="jqm-footer">' +
    '  <div style="font-size:.7em; text-align:center !important">' +
    '    <p>iPurchase &copy; 1997-2015 ISS Group - All Rights Reserved</p>' +
    '  </div>' +
    '</div>';

  var searching = null;
  var supplierAutoComplete = function (e, data) {
    if (searching) {
        clearTimeout(searching);
    }

    var $ul = $(this),
    $input = $(data.input),
    value = $input.val(),
    html = "";
    searching = setTimeout(function () {
      $ul.html("");
      if (value && value.length > 2) {
        $ul.html("<li><div class='ui-loader'><span class='ui-icon ui-icon-loading'></span></div></li>");
        $ul.listview("refresh");
        $.ajax({
          url: myURL + "getData.p", 
          dataType: "json",
          data: {
            isQAD: true,
            numRecords: 30,
            whereClause: "vd_sort begins '" + $input.val() + "' and vd_domain eq 'demo1'",
            DSName: "vd_mstr",
            fieldSet: "vd_addr,vd_sort",
            outputFormat: "json",
            h_token: sToken
          }
        }).then(function (data) {
            try {
              $.each(data.dataset.vd_mstr, function (i, val) {
                  html += "<li><a href='#' data-key='" + val.vd_addr + "'>" + val.vd_sort + " (" + val.vd_addr + ")</a></li>";
              });
            } catch(e) {}
            
            prepSearchUL($ul, html);
        });
      }
    }, 100);
  }

  var userAutoComplete = function (e, data) {
    if (searching) {
      clearTimeout(searching);
    }
    
    var $ul = $(this),
    $input = $(data.input),
    value = $input.val(),
    html = "";
    searching = setTimeout(function () {
      $ul.html("");
      if (value && value.length > 2) {
        $ul.html("<li><div class='ui-loader'><span class='ui-icon ui-icon-loading'></span></div></li>");
        $ul.listview("refresh");
        $.ajax({
          url: myURL + "getData.p", 
          dataType: "json",
          data: {
            numRecords: 30,
            whereClause: "wus_id begins '" + $input.val() + "' or wus_name begins '" + $input.val() + "'",
            DSName: "wus_mstr",
            fieldSet: "wus_id,wus_name",
            outputFormat: "json",
            h_token: sToken
          }
        }).then(function (data) {
            try {
              $.each(data.dataset.wus_mstr, function (i, val) {
                  html += "<li><a href='#' data-key='" + val.wus_id + "'>" + val.wus_name + " (" + val.wus_id + ")</li>";
              });
            } catch(e) {}
            prepSearchUL($ul, html);
        });
      }
    }, 100);
  }

  var itemInqAutoComplete = function (e, data) {
    if (searching) {
        clearTimeout(searching);
    }

    var $ul = $(this),
    $input = $(data.input),
    value = $input.val(),
    html = "";
    searching = setTimeout(function () {
      $ul.html("");
      if (value && value.length > 2) {
        $ul.html("<li><div class='ui-loader'><span class='ui-icon ui-icon-loading'></span></div></li>");
        $ul.listview("refresh");
        $.ajax({
          url: myURL + "getreqitems.p", 
          dataType: "json",
          data: {
            numRecords: 30,
            q: $input.val(),
            format: "json",
            h_token: sToken
          }
        }).then(function (data) {
            try {
              $.each(data.Item, function (i, val) {
                  html += "<li><a href='#' data-key='" + val.Nbr + "'>" + val.Nbr + " (" + val.Desc + ")</a></li>";
              });
            } catch(e) {
              
            }
            
            prepSearchUL($ul, html);
        });
      }
    }, 100);
  }

  var projectAutoComplete = function (e, data) {
    if (searching) {
        clearTimeout(searching);
    }

    var $ul = $(this),
    $input = $(data.input),
    value = $input.val(),
    html = "";
    searching = setTimeout(function () {
      $ul.html("");
      if (value && value.length > 1) {
        $ul.html("<li><div class='ui-loader'><span class='ui-icon ui-icon-loading'></span></div></li>");
        $ul.listview("refresh");
        $.ajax({
          url: myURL + "getprojects.p", 
          dataType: "json",
          data: {
            numRecords: 30,
            q: $input.val(),
            format: "json",
            h_token: sToken
          }
        }).then(function (data) {
            try {
              $.each(data.Project, function (i, val) {
                  html += "<li><a href='#' data-key='" + val.Nbr + "'>" + val.Nbr + " (" + val.Desc + ")</a></li>";
              });
            } catch(e) {}
            
            prepSearchUL($ul, html);
        });
      }
    }, 100);
  }

  var unspscInqAutoComplete = function (e, data) {
    if (searching) {
        clearTimeout(searching);
    }

    var $ul = $(this),
    $input = $(data.input),
    value = $input.val(),
    html = "";
    searching = setTimeout(function () {
      $ul.html("");
      if (value && value.length > 2) {
        $ul.html("<li><div class='ui-loader'><span class='ui-icon ui-icon-loading'></span></div></li>");
        $ul.listview("refresh");
        $.ajax({
          url: myURL + "getucodes.p", 
          dataType: "json",
          data: {
            numRecords: 30,
            q: $input.val(),
            format: "json",
            h_token: sToken
          }
        })
          .then(function (data) {
            try {
              $.each(data.uCode, function (i, val) {
                  html += "<li><a href='#' data-key='" + val.Code + "'>" + val.Code + " (" + val.Desc + ")</a></li>";
              });
            } catch(e) {
              
            }
            prepSearchUL($ul, html);
        });
      }
    }, 100);
  }

  function prepSearchUL ($ul, html) {
    $ul.html(html);
    $ul.find('a').bind("vclick", function(e) {
      var val = $(this).attr("data-key");
      $(this).parent().parent().prev().find('input').val(val);
      var field = $("#" + $(this).parent().parent().attr("data-filter-field")); 
      field.val(val);
      $(this).parent().parent().prev().find('input').bind("change, blur", function(e) {
        field.val($(this).val());
      });
      
      $ul.html("");
    });
    $ul.listview("refresh");
    $ul.trigger("updatelayout");  
  }

  function showQuickResults () {
    localData.viewReqsData = {};
    localData.viewReqsData.queryString = $("#quickSearchForm").serialize();
    localData.viewReqsData.title = "Search Results";
    localData.viewReqsData.action = SHOW_FIRST;
    localData.viewReqsData.lastRowid = "";
    changePage("#viewReqsPage");
    //return false;
  }; // showQuickResults

  function showPOResults () {
    localData.viewPOsData = {};
    localData.viewPOsData.queryString = $("#poSearchForm").serialize();
    localData.viewPOsData.title = "Search Results";
    localData.viewPOsData.action = "f";
    localData.viewPOsData.rowids = "";
    changePage("#viewPOsPage");
    return false;
  }; // showQuickResults

  function fillListsSearchPage() {
    $("#h_inq_bill").append($("<option></option>").attr("value", "").text("Select Bill To"));        
    $("#h_inq_ship").append($("<option></option>").attr("value", "").text("Select Ship To"));
    $("#h_inq_site").append($("<option></option>").attr("value", "").text("Select Site"));
    $("#h_inq_req_type").append($("<option></option>").attr("value", "").text("Select Requisition Type"));
    
    $.each(initData.ListValues, function (i, val) {
      if (val.Code == "") { return };
      if (val.Type == "BILL_TO") {
        $("#h_inq_bill").append($("<option></option>").attr("value", val.Code).text(val.Value));
      } else
      if (val.Type == "SHIP_TO") {
        $("#h_inq_ship").append($("<option></option>").attr("value", val.Code).text(val.Value));
      } else
      if (val.Type == "SITE") {
        $("#h_inq_site").append($("<option></option>").attr("value", val.Code).text(val.Value));
      } else
      if (val.Type == "REQ_TYPE") {
        $("#h_inq_req_type").append($("<option></option>").attr("value", val.Code).text(val.Value));
      } 
    });
    $("#h_inq_bill").selectmenu("refresh");
    $("#h_inq_ship").selectmenu("refresh");
    $("#h_inq_site").selectmenu("refresh");
    $("#h_inq_req_type").selectmenu("refresh");
  }
  
  function changePage(sPage, oTransition) {
   //   alert("ipur");
    if (oTransition == undefined) {
      oTransition = {
          transition: "slide"
      };
    };

    $.mobile.changePage(sPage, oTransition);
  }; //changePage

  function saveSettings() {
    localStorage.setObject('localData', localData);
  }; // saveSettings

  function getReqs () {
      localStorage.setItem("flag","");
    if (localData.viewReqsData.action == "") { return; };

    setHeader(localData.viewReqsData.title);
    
    $("#deleteMe").remove();
    
    $("#rv-reqs-table tbody").empty();
    $("#rv-reqs-table").hide();
    $("#rvNavButtons").hide();
    
    var url = myURL + "getreqs.p?" + localData.viewReqsData.queryString + 
      "&h_token="   + sToken + 
      "&action="    + localData.viewReqsData.action +
      "&lastRowid=" + localData.viewReqsData.lastRowid +
      "&numRecords=" + NUM_RECORDS;

    $.ajax({
      url: url,
      cache: false,
      async: false,
      datatype: "json",
      success: function (data) {
        var str = "";
        var bFound = false;

        try {
          localData.viewReqsData.lastRowid = data.dataset.Navigation[0].lastRowid;
          
          for(var i=0; i<data.dataset.Reqs.length; i++) {
            bFound = true;
            var req = data.dataset.Reqs[i]
            //var mq = window.matchMedia( "(min-width: 600px)" );
    
            //if (mq.matches) {
          //  {
        //   alert(req.Domain);
              $("#rv-reqs-table > tbody").append(
                "<tr data-rowid='" + req.myRowid + "'>" +
                "<td class='title'><a href='#viewReqPage' data-domain='" + req.Domain + "' data-nbr='" +  req.ReqNbr + "'>" + req.ReqNbr + "</a></td>" +
                "<td class='bold'>" + req.SupplierName + "</td>" +
                "<td>" + req.Status + "</td>" +
                "<td>" + req.Type.toTitleCase() + "</td>" +
                "<td class='table-right bold'>" + req.Total + "</td>" +
                "<td>" + req.UserName + "</td>" +
                "<td class='table-right'>" + req.EntryDate + "</td>" +
                "</tr>");
           // }
          }

          $("#rv-reqs-table").show();
          $("#rvNavButtons").show();
        } catch (e) {console.log(e);}

        //$("#rv-reqs-table").table("refresh");
        $('#rv-reqs-table tbody a').bind('vclick', function(e) {
          //alert("vclick");
          localData.viewReqData = {};
          localData.viewReqData.reqNbr = $(this).attr('data-nbr');
          localData.viewReqData.Domain = $(this).attr('data-domain');
          localData.viewReqData.rowid = $(this).attr('data-rowid');
        });

        if (localData.viewReqsData.action == SHOW_FIRST) {
          $("#firstReqsButton").prop('disabled', true).addClass('ui-disabled');
          
          if (localData.viewReqsData.lastRowid == "") {
            $("#nextReqsButton").prop('disabled', true).addClass('ui-disabled');
          } else {
            $("#nextReqsButton").prop('disabled', false).removeClass('ui-disabled');
          }
        } else {
          $("#firstReqsButton").prop('disabled', false).removeClass('ui-disabled');
          
          if (localData.viewReqsData.lastRowid == "") {
            $("#nextReqsButton").prop('disabled', true).addClass('ui-disabled');
          } else {
            $("#nextReqsButton").prop('disabled', false).removeClass('ui-disabled');
          }
        }

        scrollToTop();

        if (!bFound) {
          if ($(".jqm-header h1", getActivePage()).text() == "Pending Approval") {
            $("#rv-reqs-table").before("<h2 id='deleteMe'>Nothing for you to approve.<h2>");
          } else {
            $("#rv-reqs-table").before("<h2 id='deleteMe'>Requisitions not found.<h2>");
          }
        };
      }
    });
//    $("#rvNavButtons").find("a").removeClass("ui-btn-active ui-focus");
    
    localData.viewReqsData.action = "";
  }; // getReqs

  function getReq () {

      var pQuery = "";
      var url = "";
      if(localStorage.getItem("ShowReq")=="1"){
      
          var stringObject = "{showReqValue:'"+localStorage.getObject("showReqValue")+"', DomainValue:'"+localStorage.getObject("DomainValue")+"', showTokenValue:'"+localStorage.getObject("showTokenValue")+"'}";
          eval('var object='+stringObject);
//          pQuery="domain="+object.DomainValue+"&h_req_nbr="+object.showReqValue+"&h_token="+object.showTokenValue;
//          url=myURL+"getreq.p?"+pQuery;
          sToken = object.showTokenValue;
          /*localData.viewReqData.reqNbr = $(this).attr('data-nbr');
           localData.viewReqData.Domain = $(this).attr('data-domain');
           localData.viewReqData.rowid = $(this).attr('data-rowid');*/
          localData.viewReqData = {};
          localData.viewReqData.Domain = object.DomainValue;
          localData.viewReqData.reqNbr = object.showReqValue;
      }

      pQuery="domain="+localData.viewReqData.Domain+"&h_req_nbr="+localData.viewReqData.reqNbr+"&h_token="+sToken;
      
      url=myURL+"getreq.p?"+pQuery;

 //     alert("url 1"+url);
    $.ajax({
      url: url,
      cache: false,
      async: false,
      datatype: "json",
      success: function (data) {
          // alert("data");
        currentReq = data.dataset.ttReq[0];
        //   alert("flag"+localStorage.getItem("flag"));
            if(localStorage.getItem("flag")==1){
         //  alert("if");
           getItem();
           }
           else{
           showReq();
           }
        
      },
           error: function (msg)
           {
             showAlert("Failed: "+ msg.status + ": " + msg.statusText,"iPurchase");
         //  $.mobile.loading( 'hide');
           }
           });
  } // getReq

  function getMenu($panel) {
    if (typeof menu != "object") {
      $.ajax({
        url: myURL + "mobinit.p?h_token=" + sToken,
        cache: false,
        async: false,
        datatype: "json",
        success: function (data) {
          initData = data.dataset;
             //alert(JSON.stringify(data.dataset));
        }
      });
    };
    showMenu($panel);
  }; // getMenu
    
  function showMenu ($panel) {
    var data = initData;
    try {
      var bFound = false;
      var str = "<li data-role='list-divider'><p>My Views</p></li>";
      for(var i=0; i<data.View.length; i++) {
        var view = data.View[i];
        if (!view.isSystem) {
          str+= '<li><a class="viewClass ui-btn ui-btn-icon-left ui-icon-eye" href="#viewReqsPage" data-name="' + encodeURIComponent(view.Id) + '">' + view.Name + "</a></li>";
          bFound = true;
        };
      };
      if (bFound) {
        $(".jqm-list", $panel).append(str);
      };
      
      bFound = false;
      str = "<li data-role='list-divider'><p>Shared Views</p></li>";
      for(var i=0; i<data.View.length; i++) {
        var view = data.View[i];
        if (view.isSystem) {
          bFound = true;
          str+= "<li><a class=' ui-btn ui-btn-icon-left ui-icon-eye' href='#viewReqsPage' data-name='" + view.Id + "'>" + view.Name + "</a></li>";
        };
      };
      if (bFound) {
        $(".jqm-list", $panel).append(str);
      };
    } catch (e) {console.log(e);};
  }; // showMenu

  function getItem () {
     // alert("getItem");
    $.each(currentReq.ttReqD, function(i) {
      var line = currentReq.ttReqD[i];
      if (line.xxreqd_line == localData.viewItemData.line) {
          
        setHeader(line.xxreqd_item);
        
        $("#form_item :input").each(function() {
          var rv_field = $(this).attr("id");
          var field = rv_field.substr(2);
    
          if ($(this).attr("type") === "checkbox") {
            $("#" + rv_field).attr("checked", line[field]).flipswitch("refresh");
          } else {
            $("#" + rv_field).val(line[field]).trigger("refresh");
          };
          $(this).attr('disabled', 'disabled');
        });
        showAttachments(line.ttLineAttach, $("#lineAttachments"));
           
        $("#viewItemPage").trigger("refresh");

        // break out of the loop
        return false;
      }; 
    });
  }

  function getUser () {
    var url = myURL + "getusermob.p" +
      "?h_token=" + sToken +
      "&user=" + localData.viewUserData.userid; 
    
    $.ajax({
      url: url,
      cache: false,
      async: false,
      datatype: "json",
      success: function (data) {
        try {
          var user = data.User[0];
          var activePage = getActivePage();
          
          setHeader(user.wus_name);
          
          $("#downloadContact").prop("href", myURL + "getvcard.p?h_token=" + sToken + "&user=" + user.wus_id).trigger('refresh');
          
          $(".userName", activePage).text(user.wus_name);
          $(".userSupervisor", activePage).text(user.SupervisorName);
          $(".userDelegate", activePage).text(user.DelegateName);
          
          if (user.wus_email > "") {
            $(".userEmail", activePage).text(user.wus_email).next().prop("href", "mailto:" + user.wus_email);
            $(".userEmail", activePage).next().show();
          } else {
            $(".userEmail", activePage).next().hide();
          };
          
          if (user.wus_phone > "") {
            $(".userPhone", activePage).text(user.wus_phone).next().prop("href", "tel:" + user.wus_phone).next().prop("href", "sms:" + user.wus_phone);
            $(".userPhone", activePage).next().show().next().show();
          } else {
            $(".userPhone", activePage).next().hide().next().hide();
          };
          
          if (user.wus_fax > "") {
            $(".userMobile", activePage).text(user.wus_fax).next().prop("href", "tel:" + user.wus_fax).next().prop("href", "sms:" + user.wus_fax);
            $(".userMobile", activePage).next().show().next().show();
          } else {
            $(".userMobile", activePage).next().hide().next().hide();
          };
          
          if (user.wus_street1 > "" && user.wus_city > "") {
            var sAddress = user.wus_street1 + ", " + user.wus_city + ", " + user.wus_state + " " + user.wus_post;
            $(".userAddress", activePage).text(sAddress).next().prop("href", "http://maps.apple.com/?daddr=" + sAddress);
            $(".userAddress", activePage).next().show();
          } else {
            $(".userAddress", activePage).next().hide();
          };
          
          $(".rv-user-table").trigger('refresh');
          $(".viewUserPage").trigger('refresh');
        }
        catch(e) {console.log(e);};  
      }
    });
  }; // getUser

  function getContact() {
    setHeader(localData.viewContactData.name);
    
    if (localData.viewContactData.email > "") {
      $(".contactEmail").text(localData.viewContactData.email).next().prop("href", "mailto:" + localData.viewContactData.email);
      $(".contactEmail").next().show();
    } else {
      $(".contactEmail").next().hide();
    };
    
    if (localData.viewContactData.phone > "") {
      $(".contactPhone").text(localData.viewContactData.phone).next().prop("href", "tel:" + localData.viewContactData.phone).next().prop("href", "sms:" + localData.viewContactData.phone);
      $(".contactPhone").next().show().next().show();
    } else {
      $(".contactPhone").next().hide().next().hide();
    };
    
    if (localData.viewContactData.mobile > "") {
      $(".contactMobile").text(localData.viewContactData.mobile).next().prop("href", "tel:" + localData.viewContactData.phone).next().prop("href", "sms:" + localData.viewContactData.phone);
      $(".contactMobile").next().show().next().show();
    } else {
      $(".contactMobile").next().hide().next().hide();
    };
    
    if (localData.viewContactData.fax > "") {
      $(".contactFax").text(localData.viewContactData.fax).next().prop("href", "http://maps.apple.com/?daddr=" + localData.viewContactData.fax);
      $(".contactFax").next().show();
    } else {
      $(".contactFax").next().hide();
    };
    
    $(".rv-contact-table").trigger('refresh');
    $(".viewContactPage").trigger('refresh');
  }; // getContact

  function showContactLink (sName, sEmail, sPhone, sMobile, sFax) {
    if (sEmail == "" && sPhone == "" && sMobile == "" & sFax == "") {
      return "";
    };
    
    return '&nbsp;<a ' +
           'style="background-color: transparent !important; border: 0 !important;" ' +
           'href="#viewContactPage" ' +
           'class="contactLink ui-btn ui-btn-a ui-icon-action ui-btn-inline ui-btn-icon-notext" ' +
           'data-contactname="' + sName + '" ' +
           'data-contactemail="' + sEmail + '" ' +
           'data-contactphone="' + sPhone + '" ' +
           'data-contactmobile="' + sMobile + '" ' +
           'data-contactfax="' + sFax + '" ' +
           '>Contact</a>';
  }; // showContactLink

  function showUserLink (sUserid) {
    if (sUserid == "") {
      return "";
    }
    
    return '&nbsp;<a ' +
           'style="background-color: transparent !important; border: 0 !important;" ' +
           'href="#viewUserPage" ' +
           'class="userLink ui-btn ui-btn-a ui-icon-user ui-btn-inline ui-btn-icon-notext" ' +
           'data-userid="' + sUserid + '" ' +
           '>Contact</a>';
  }; // showUserLink

  function showGroupLink (sGroup) {
    if (sGroup == "") {
      return "";
    };
    
    return '&nbsp;<a ' +
           'style="background-color: transparent !important; border: 0 !important;" ' +
           'href="#viewGroupPage" ' +
           'class="groupViewLink ui-btn ui-btn-a ui-icon-group ui-btn-inline ui-btn-icon-notext" ' +
           'data-groupid="' + sGroup + '" ' +
           '>Members</a>';
  }; showGroupLink

  function getStatusIcon(sStatus) {
    var sIcon = "";
    
    switch (sStatus.toLowerCase()) {
      case "approved":
        sIcon = "ui-icon-check ui-alt-icon ui-nodisc-icon ";
        break;
      case "pending":
        sIcon = "ui-icon-clock ui-alt-icon ui-nodisc-icon ";
        break;
      case "rejected":
        sIcon = "ui-icon-delete ui-alt-icon ui-nodisc-icon ";
        break;
      case "retracted":
        sIcon=  "ui-icon-back ui-alt-icon ui-nodisc-icon ";
        break;
      case "removed":
        sIcon = "ui-icon-minus ui-alt-icon ui-nodisc-icon ";
        break;
      case "rerouted":
        sIcon = "ui-icon-refresh ui-alt-icon ui-nodisc-icon ";
        break;
      case "no longer required":
        sIcon = "ui-icon-forbidden";
        break;
      otherwise
        return "";
    }
    if (sIcon > "") {
      var str =      '<a ' +
       'style="background-color: transparent !important; border: 0 !important;" ' +
       'href="#" ' +
       'class="userLink ui-btn ui-btn-a ' + sIcon + ' ui-btn-inline ui-btn-icon-notext" ' +
       '></a>&nbsp;';
      
     return str; 
    };
    return "";
  }; // getStatusIcon

  function approveReq (bApprove) {
    if (bApprove == false && $("#h_approval_notes").val() == "") {
      showErrorMessage("Rejection notes are required");
      return;
    };

    if (bApprove == false && $("#h_rejection_code").val() == "") {
      showErrorMessage("Rejection reason code is required");
      return;
    };

    var url = myURL + "mobapproval.p?h_token=" + sToken +
      "&h_approve=" + bApprove +
      "&h_rowid=" + currentReq.myRowid +
      "&h_approval_notes=" + encodeURIComponent($("#h_approval_notes").val()) +
      "&h_rejection_code=" + $("#h_rejection_code").val();

    $.ajax({
      url: url,
      cache: false,
      async: false,
      datatype: "json",
      success: function (data) {
        $("#h_approval_notes").val("");
        try {
          
          getReq();
          
          if (data.Result[0].Error == true) {
            showErrorMessage(data.Result[0].ErrorMessage);
            return;
          };
         
          if (data.Result[0].WarningMessage > "") {
            showWarningMessage(data.Result[0].WarningMessage);
          };

          getReqs();
        } catch (e) {
          showErrorMessage("Unable to approve at this time. " + e.toString()) 
        };
      }
    });
  }; // approveReq

  function showReq () {
      localStorage.setItem("ShowReq","");
      localStorage.setItem("showReqValue","");
      localStorage.setItem("DomainValue","");
    $("#heaerSet").empty();
    $("#rvHeaderTop").empty();
    $("#rv-item-table tbody").empty();
    $("#rv-supplier-info-table tbody").empty();
    $("#rv-billing-info-table tbody").empty();
    $("#rv-user-info-table tbody").empty();
    $("#rv-other-info-table tbody").empty();
    $("#h_rejection_code").empty();
//    $('#headerTab').trigger('click');
    try {
      $("#h_rejection_code").empty();
      var rejects = initData.RejectionCodes;
      for(var i=0; i<rejects.length; i++) {
        var reason = rejects[i];
        $("#h_rejection_code").append("<option value='" + reason.Code + "'>" + reason.Name + "</option");
      }
      
    } catch(e) {console.log(e);} 
    
    try {
      var req = currentReq;
      var sText = req.xxreq_status_name;

      localData.viewReqData.rowid = req.myRowid;

      var sPrintReq;
var sPrintURL;
      if (initData.Settings[0].AllowReqPrint) {
      
        sPrintURL=myURL +"outreq.p?h_token=" + sToken + "&h_req_nbr=" + req.xxreq_nbr + "&Domain=" + req.xxreq_domain;

          sPrintReq = "&nbsp;" +
          '<a data-inline="true" style="background-color: transparent !important; border: 0 !important;" class="ui-btn ui-btn-a ui-icon-print ui-btn-inline ui-btn-icon-notext " href="#" onclick=openImageInInAppBrowser("'+sPrintURL+'")>Print</a>';
      };
      
      var str = "<li style='padding: 10px; color: black; background-color: rgb(246, 246, 246) !important'>" + "<p><strong>" + sPrintReq + req.xxreq_vendor_name + "</strong></p>" +
      "<p id='rvReqStatus'>" +  + "</p>" +
      "<p>" + req.xxreq_type_name + "</p>" +
      "<span class='ui-li-count'>" + req.xxreq_cost_formatted + "</span>" +
      "<p class='ui-li-aside'>" + req.xxreq_entry_date + "</p>" +
      "</li>";
      
      $("#rvHeaderTop").append(str);
        localStorage.setItem("req_nbr",req.xxreq_nbr);
      setHeader("Req: " + req.xxreq_nbr);
      
      if (req.xxreq_update_po) {
        sText += " - Change Order";
      }
      
      $("#rvReqStatus").html(sText).trigger("refresh");

      var sPrint = "";
      if (initData.Settings[0].AllowPOPrint && 
          req.xxreq_po_nbr > "" && 
          req.xxreq_po_nbr.toLowerCase() != "pending" &&
          req.xxreq_po_nbr.toLowerCase() != "error") {
          
//        sPrint = "&nbsp;" +
//            '<a style="background-color: transparent !important; border: 0 !important;" ' +
//            'class="ui-btn ui-btn-a ui-icon-print ui-btn-inline ui-btn-icon-notext" ' +
//            "href='" + myURL + "reprintpo.p?h_token=" + sToken + "&h_po=" + req.xxreq_po_nbr + "' " +
//            'rel=external target=_blank>Print</a>';
          
          newURL = myURL + "reprintpo.p?h_token=" + sToken + "&h_po=" + req.xxreq_po_nbr;
          sPrint = "&nbsp;" +
          '<a style="background-color: transparent !important; border: 0 !important;" ' +
          'class="ui-btn ui-btn-a ui-icon-print ui-btn-inline ui-btn-icon-notext" href="#" onclick=openImageInInAppBrowser("'+newURL+'">Print</a>';
          
      }
      
      $("#rv-supplier-info-table > tbody").append(
          "<tr>" +
          "<td>" + req.xxreq_po_nbr + sPrint + "</td>" +
          "<td>" + req.xxreq_vendor + "-" + req.xxreq_vendor_name + "</td>" +
          "<td>" + req.xxreq_supplier_contact + showContactLink(req.xxreq_supplier_contact, req.xxreq_supplier_email, req.xxreq_supplier_phone, "", "") + "</td>" +
          "<td>" + req.xxreq_supplier_phone + "</td>" +
          "<td>" + req.xxreq_supplier_fax + "</td>" +
          "<td>" + req.xxreq_supplier_email + "</td>" +
          "</tr>"
      );

      $("#rv-billing-info-table > tbody").append(
          "<tr>" +
          "<td>" + req.xxreq_bill_to_name + "</td>" +
          "<td>" + req.xxreq_ship_to_name + "</td>" +
          "<td>" + req.xxreq_site + "</td>" +
          "<td>" + req.xxreq_currency + "</td>" +
          "<td>" + req.xxreq_freight_terms_name + "</td>" +
          "<td>" + req.xxreq_ship_via_name + "</td>" +
          "<td>" + req.xxreq_project + "</td>" +
          "<td>" + yn(req.xxreq_taxable) + "</td>" +
          "</tr>"
      );

      $("#rv-user-info-table > tbody").append(
          "<tr>" +
          "<td>" + req.xxreq_buyer_name + showUserLink(req.xxreq_buyer) + "</td>" +
          "<td>" + req.xxreq_userid_name + showUserLink(req.xxreq_userid) + "</td>" +
          "<td>" + req.xxreq_obo_name + showUserLink(req.xxreq_obo) + "</td>" +
          "<td>" + req.xxreq_deliver_to_name + showUserLink(req.xxreq_deliver_to) + "</td>" +
          "</tr>"
      );

      $("#rv-other-info-table > tbody").append(
          "<tr>" +
          "<td class='table-right'>" + req.xxreq_need_date + "</td>" +
          "<td class='table-right'>" + (req.xxreq_perf_date ? req.xxreq_perf_date : req.xxreq_need_date) + "</td>" +
          "<td>" + req.xxreq_copied_from + "</td>" +
          "<td>" + yn(req.xxreq_po_required) + "</td>" +
          "<td>" + yn(req.xxreq_cons) + "</td>" +
          "<td>" + yn(req.xxreq_all_items) + "</td>" +
          "<td>" + yn(req.xxreq_log5) + "</td>" +
          "<td>" + yn(req.xxreq_blanket) + "</td>" +
          "</tr>"
      );

//      $(".printpo").each(function() {
//        $(this).bind("vclick", function(e) {
//          showDialog($(this).attr("data-href"));
//          e.preventDefault();
//          return false;
//        })
//      })

      $("#form_rv :input").each(function() {
        //$(this).addClass('ui-mini');
        var rv_field = $(this).attr("id");
        var field = rv_field.substr(3);
        if ($(this).attr("type") === "checkbox") {
          $("#" + rv_field).attr("checked", req[field]).flipswitch("refresh");
        } else
          $("#" + rv_field).val(req[field]).trigger("refresh");
        
        $(this).attr('disabled', 'disabled');
      })

      var iLength = 0;
      try {
        iLength = req.ttAudit.length
      } catch(e) {}
      
      $("#approvalErrorDisplay").remove();
      if (iLength > 0) {
        $("#approvalActions").show();
        $("#h_approval_attempts_picker").empty();
        var aAttempts = [];
        for ( var i = 0; i < req.ttAudit.length; i++) {
          aAttempts.push(req.ttAudit[i].xxreq_submit_attempt);
        }
      
        aAttempts = ArrNoDupe(aAttempts); // remove duplicates and sort descending
        showApprovals(aAttempts[0]); // show latest
        for ( var i = 0; i < aAttempts.length; i++) {
          if (aAttempts[i] == "9999999") {
            $("#h_approval_attempts_picker").append("<option value='" + aAttempts[i] + "'>Approval Simulation</option");
          } else {
            $("#h_approval_attempts_picker").append("<option value='" + aAttempts[i] + "'>Approval Attempt " + aAttempts[i] + "</option");
          }
        }
      } else {
        /* couldn't run simulation - error occurred */
        $("#approvalActions").hide();
        $("#approvalActions").after("<div id='approvalErrorDisplay'>" + req.approvalSimError + "</div>");
      }
//        alert("call showAttachment");
      showAttachments(req.ttHeaderAttach, $("#headerAttachments"));

      for ( var i = 0; i < req.ttReqD.length; i++) {
        var line = req.ttReqD[i];
        var str=
          "<tr>" +
          "<td class='title'><a href='#viewItemPage' data-domain='" + line.xxreqd_domain + "' data-nbr='" + line.xxreqd_nbr + "' data-line='" + line.xxreqd_line + "'>" + line.xxreqd_item + "</a></td>" +
          "<td class='description'><div style='inline'>" + line.xxreqd_desc + "</div></td>" +
          "<td class='table-right'>" + line.xxreqd_qty_formatted + "</td>" +
          "<td>" + line.xxreqd_uom_name + "</td>" +
          "<td class='table-right'>" + line.xxreqd_cost_formatted + "</td>" +
          "<td class='table-right'>" + line.xxreqd_total_formatted + "</td>" +
          "<td>" + line.xxreqd_line + "</td>" +
          "</tr>";

        $("#rv-item-table > tbody").append(str);
      }
      
      $("#rv-item-table tbody").find("a").bind('vclick', function(e) {
        if ($(this).attr("href") == "#viewItemPage") {
          localData.viewItemData = {};
          localData.viewItemData.domain = $(this).attr('data-domain');
          localData.viewItemData.reqNbr = $(this).attr('data-nbr');
          localData.viewItemData.line   = $(this).attr('data-line');
        }
      });
    } catch (e) {console.log(e);}

    $(".contactLink", getActivePage()).bind('vclick', function(e) {
      localData.viewContactData = {};
      localData.viewContactData.name = $(this).attr('data-contactname');
      localData.viewContactData.email = $(this).attr('data-contactemail');
      localData.viewContactData.phone = $(this).attr('data-contactphone');
      localData.viewContactData.mobile = $(this).attr('data-contactmobile');
      localData.viewContactData.fax = $(this).attr('data-contactfax');
    });

    $(".userLink", getActivePage()).bind('vclick', function(e) {
      localData.viewUserData = {};
      localData.viewUserData.userid = $(this).attr('data-userid');
    });

    $(".groupViewLink", getActivePage()).bind('vclick', function(e) {
      localData.viewGroupData = {};
      localData.viewGroupData.groupid = $(this).attr('data-groupid');
    });
    
    $("#h_rejection_code").selectmenu("refresh");
    $("#h_approval_attempts_picker").selectmenu("refresh");
    $("#rv-supplier-info-table").table("refresh");
    $("#rv-billing-info-table").table("refresh");
    $("#rv-user-info-table").table("refresh");
    $("#rv-other-info-table").table("refresh");
    $("#rv-item-table").table("refresh");
    $("#rvHeaderTop").trigger("refresh");
    $("#rvRequisitionInformation").trigger("refresh");
    $("#rvOtherReqInformation").trigger("refresh");
    $("#viewReqPage").trigger("refresh");
  }; // showReq

  function showApprovals (iAttempt) {
    $("#rv-approval-table > tbody").empty();
    $("#approvalActions").hide();
    var req = currentReq;
    
    for ( var i = 0; i < req.ttAudit.length; i++) {
      var app = req.ttAudit[i];
      if (app.xxreq_submit_attempt != iAttempt) {
        continue;
      }

      if (req.isApprover == "yes") {
        $("#approvalActions").show();
      }

      var sUserLink = "";
    
      if (!app.isGroup) {
        sUserLink = showUserLink(app.xxreq_app_id);
      } else {
        sUserLink = showGroupLink(app.xxreq_app_id);
      }
      
      var str=
        "<tr>" +
        "<td class='title'>" + app.xxreq_app_id_name + sUserLink + "</td>" +
        "<td class='table-right'>" + app.xxreq_app_seq + "</td>" +
        "<td>" + app.xxreq_actual_approver_name + showUserLink(app.xxreq_actual_approver) + "</td>" +
        "<td>" + getStatusIcon(app.xxreq_status) + app.xxreq_status + "</td>" +
        "<td>" + app.xxreq_app_notes.escape() + "</td>" +
        "<td>" + dateTimeTZRenderer(app.xxreq_app_datetime) + "</td>" +
        "<td>" + dateTimeTZRenderer(app.xxreq_active_datetime) + "</td>" +
        "</tr>";

      $("#rv-approval-table > tbody").append(str);
    }

    $('#h_approval_attempts_picker').val(iAttempt).selectmenu("refresh");
    $("#rv-approval-table").table("refresh");
    $(".userLink", $("#rv-approval-table")).bind('vclick', function(e) {
      localData.viewUserData = {};
      localData.viewUserData.userid = $(this).attr('data-userid');
    });
  }; // showApprovals

  function getGroup() {
    var url = myURL + "getgroupmembers.p?group=" + localData.viewGroupData.groupid + 
      "&h_token="   + sToken;
   
    $("#rv-group-table tbody").empty();
    setHeader("Group Info");
    $.ajax({
      url: url,
      cache: false,
      async: false,
      datatype: "json",
      success: function (data) {

        try {
          var users = data.Member;
          
          for ( var i = 0; i < users.length; i++) {
            var user = users[i];

            var $tr = $(
            "<tr>" +
            '<td class="title"><span class="userName"></span></td>' +
            '<td><span class="userEmail"></span>&nbsp;&nbsp;&nbsp;&nbsp;<a style="background-color: transparent !important; border: 0 !important;" href="#" class="ui-btn ui-btn-a ui-icon-mail ui-btn-inline ui-btn-icon-notext"></a></td>' +
            '<td><span class="userPhone"></span>&nbsp;&nbsp;&nbsp;&nbsp;<a style="background-color: transparent !important; border: 0 !important;" href="#" class="ui-btn ui-btn-a ui-icon-phone ui-btn-inline ui-btn-icon-notext"></a>&nbsp;&nbsp;&nbsp;&nbsp;<a style="background-color: transparent !important; border: 0 !important;" href="#" class="ui-btn ui-btn-a ui-icon-comment ui-btn-inline ui-btn-icon-notext"></a></td>' +
            '<td><span class="userMobile"></span>&nbsp;&nbsp;&nbsp;&nbsp;<a style="background-color: transparent !important; border: 0 !important;" href="#" class="ui-btn ui-btn-a ui-icon-phone ui-btn-inline ui-btn-icon-notext"></a>&nbsp;&nbsp;&nbsp;&nbsp;<a style="background-color: transparent !important; border: 0 !important;" href="#" class="ui-btn ui-btn-a ui-icon-comment ui-btn-inline ui-btn-icon-notext"></a></td>' +
            '<td><span class="userAddress"></span>&nbsp;&nbsp;&nbsp;&nbsp;<a target="_new" style="background-color: transparent !important; border: 0 !important;" href="#" class="ui-btn ui-btn-a ui-icon-location ui-btn-inline ui-btn-icon-notext"></a></td>' +
            '<td><span class="userSupervisor"></td>' +
            '<td><span class="userDelegate"></td>' +
            '</tr>');
            
            $(".userName", $tr).text(user.wus_name);
            $(".userSupervisor", $tr).text(user.SupervisorName);
            $(".userDelegate", $tr).text(user.DelegateName);
            
            if (user.wus_email > "") {
              $(".userEmail", $tr).text(user.wus_email).next().prop("href", "mailto:" + user.wus_email);
              $(".userEmail", $tr).next().show();
            } else {
              $(".userEmail", $tr).next().hide();
            }
            
            if (user.wus_phone > "") {
              $(".userPhone", $tr).text(user.wus_phone).next().prop("href", "tel:" + user.wus_phone).next().prop("href", "sms:" + user.wus_phone);
              $(".userPhone", $tr).next().show().next().show();
            } else {
              $(".userPhone", $tr).next().hide().next().hide();
            }
            
            if (user.wus_fax > "") {
              $(".userMobile", $tr).text(user.wus_fax).next().prop("href", "tel:" + user.wus_fax).next().prop("href", "sms:" + user.wus_fax);
              $(".userMobile", $tr).next().show().next().show();
            } else {
              $(".userMobile", $tr).next().hide().next().hide();
            }
            
            if (user.wus_street1 > "" && user.wus_city > "") {
              var sAddress = user.wus_street1 + ", " + user.wus_city + ", " + user.wus_state + " " + user.wus_post;
              $(".userAddress", $tr).text(sAddress).next().prop("href", "http://maps.apple.com/?daddr=" + sAddress);
              $(".userAddress", $tr).next().show();
            } else {
              $(".userAddress", $tr).next().hide();
            }
            
            $("#rv-group-table tbody").append($tr);
          }
        } catch(e) {console.log(e);}
        
        $("#rv-group-table").table("refresh");
      }
    });
  }; // getGroup

  function setHeader(sText) {
    $(".jqm-header h1", getActivePage()).text(sText);  
  }

  function getOOF () {
    var url = myURL + "moboof.p?h_token=" + sToken + "&h_timezone=" + new Date().getTimezoneOffset() * -1;
    
    $("#h_delegate").empty();
    $.ajax({
      url: url,
      cache: false,
      async: false,
      datatype: "json",
      success: function (data) {
        var oof = data.dataset.OOF[0];
        $("#oofStatus").text(oof.Status).trigger('refresh');

        var delegate = data.dataset.Delegate;
        
        var mySelect = $("#h_delegate"); 
        mySelect.append($("<option></option>").attr("value", "").text("Select Delegate"));
        $.each(delegate, function(i) {
          mySelect.append($("<option></option>").attr("value", delegate[i].Userid).text(delegate[i].Name)); 
        });
        mySelect.val(oof.Delegate);
        
        $(".oof_timezone_name").text(getTimeZone()); // Pacific Daylight Time
        $("#h_oof_start_date").val(oof.StartDate);
        $("#h_oof_start_time").val(oof.StartTime);
        $("#h_oof_end_date").val(oof.EndDate);
        $("#h_oof_end_time").val(oof.EndTime);
      }
    });
    $("#h_delegate").selectmenu("refresh");
  }; // getOOF()

  function saveOOF () {
    var url = myURL + "moboof.p?b_saveoof=true&" + $("#oofForm").serialize() + "&h_token=" + sToken + "&h_timezone=" + new Date().getTimezoneOffset() * -1;
    
    $.ajax({
      url: url,
      cache: false,
      async: false,
      datatype: "json",
      success: function (data) {
        
        if (data.dataset.Result[0].Error == true) {
          showErrorMessage(data.dataset.Result[0].ErrorMessage);
          return;
        };
       
        if (data.dataset.Result[0].WarningMessage > "") {
          showWarningMessage(data.dataset.Result[0].WarningMessage);
        };
      
        getOOF();
      }
    });
  } // saveOOF ()

  function clearOOF() {
    $("#oofForm")[0].reset();
    saveOOF();
  }

  function getTimeZone() {
    return /\((.*)\)/.exec(new Date().toString())[1];
  } 

  function showAttachments(files, element) {
 //alert("showAttachments");
    element.empty();

    try {
        var imgFileName;
      $.each(files, function(i) {
        var file = files[i];
             var fname=file.xxreq_filename.split('-');
              imgFileName = file.myURL;
             element.append($('<li/>', {
          "data-icon": "cloud-download"
        }).append(
            "<a href='#' onclick=openImageInInAppBrowser('"+imgFileName+"')>" +
            "<h1>" + fname[1] + "</h1>" +
            "<p>" + file.xxreq_user + " " + dateTimeTZRenderer(file.xxreq_date) + "</p>" +
            "<p class='ui-li-aside'>" + (file.xxreq_int_ext ? "Internal" : "External") + "</p>" +
            "</a>"
        ));
      });
    } catch (e) {}
    element.listview("refresh");
      $.mobile.loading( 'hide');
  };


function openImageInInAppBrowser(fileName){
    window.open(fileName,'_blank','location=yes','zoom=no');
}


  function clearSearch() {
    $('#quickSearchForm')[0].reset();
    $("#h_inq_supplier").parents("form").find(".ui-input-search input").val("");
  };

  function clearPOSearch() {
    $('#poSearchForm')[0].reset();
    $("#h_poinq_supplier").parents("form").find(".ui-input-search input").val("");
  };

  function getPOs () {
    if (localData.viewPOsData.action == "") { return; };
    
    setHeader(localData.viewPOsData.title);
    
    $("#rv-pos-table tbody").empty();
    $("#rv-pos-table").hide();
    $("#poNavButtons").hide();
    $("#deleteMePO").remove();
    
    var url = myURL + "getpos.p?" + localData.viewPOsData.queryString + 
      "&h_token="   + sToken + 
      "&b_action="    + localData.viewPOsData.action +
      "&h_po_nav_rowids=" + localData.viewPOsData.rowids +
      "&numRecords=" + NUM_RECORDS;

    $.ajax({
      url: url,
      cache: false,
      async: false,
      datatype: "json",
      success: function (data) {
        var str = "";
        var bFound = false;

        try {
          localData.viewPOsData.rowids = data.dataset.Navigation[0].Rowids;
          
          for(var i=0; i<data.dataset.PO.length; i++) {
            bFound = true;
            var po = data.dataset.PO[i]

            var cStatus = "Open";
            if (po.ttpo_stat == "C") {
              cStatus = "Closed";
            } else
            if (po.ttpo_stat == "X") {
              cStatus = "Cancelled";
            }

            var sPrint = "";
           var sLink = "";
            if (initData.Settings[0].AllowPOPrint) {
           
//              sPrint = "&nbsp;" +
//                '<a style="background-color: transparent !important; border: 0 !important;" ' +
//                'class="ui-btn ui-btn-a ui-icon-print ui-btn-inline ui-btn-icon-notext" ' +
//                "href='" + myURL + "reprintpo.p?h_token=" + sToken + "&h_po=" + po.ttpo_nbr + "' " +
//                'rel=external target=_new>Print</a>';
           
           newURL = myURL + "reprintpo.p?h_token=" + sToken + "&h_po=" + po.ttpo_nbr;
           sPrint = "&nbsp;" +
           '<a style="background-color: transparent !important; border: 0 !important;" ' +
           'class="ui-btn ui-btn-a ui-icon-print ui-btn-inline ui-btn-icon-notext" href="#" onclick=openImageInInAppBrowser("'+newURL+'")>Print</a>';
           
            }
            
            $("#rv-pos-table > tbody").append(
              "<tr data-rowid='" + "'>" +
//              "<td class='title'><a class='poViewLink' href='#viewPOPage' data-domain='" + po.ttpo_domain + "' data-nbr='" +  po.ttpo_nbr + "'>" + po.ttpo_nbr + "</a>" + sPrint + "</td>" +
              "<td class='title'>" + po.ttpo_nbr + sPrint + "</td>" +
              "<td>" + po.vendor_name + "</td>" +
              "<td>" + cStatus + "</td>" +
              "<td class='table-right'>" + (po.ttpo_ord_date ? po.ttpo_ord_date : "&nbsp;") + "</td>" +
              "<td class='table-right'>" + (po.ttpo_due_date ? po.ttpo_due_date : "&nbsp;") + "</td>" +
              "<td>" + (po.ttpo_buyer ? po.ttpo_buyer : "&nbsp;") + "</td>" +
              "<td class='table-right'>" + po.ttpo_rev + "</td>" +
              "</tr>"
            );
          }

          $("#rv-pos-table").show();
          $("#poNavButtons").show();

          if (data.dataset.Navigation[0].HasFirst) {
            $("#firstPOsButton").prop('disabled', false).removeClass('ui-disabled');
          } else {
            $("#firstPOsButton").prop('disabled', true).addClass('ui-disabled');
          }
          if (data.dataset.Navigation[0].HasNext) {
            $("#nextPOsButton").prop('disabled', false).removeClass('ui-disabled');
          } else {
            $("#nextPOsButton").prop('disabled', true).addClass('ui-disabled');
          }
          localData.viewPOsData.action = "";        
        } catch (e) {
          console.log(e);
          localData.viewPOsData.action = "";
        }

        $('#rv-pos-table tbody .poViewLink').bind('vclick', function(e) {
          showWarningMessage("Coming Soon");
          e.preventDefault();
//          localData.viewPOData = {};
//          localData.viewPOData.reqNbr = $(this).attr('data-nbr');
//          localData.viewPOData.Domain = $(this).attr('data-domain');
//          localData.viewPOData.rowid = $(this).attr('data-rowid');
        });

        $("#rv-pos-table").table("refresh");
        //getActivePage().trigger("refresh");
        scrollToTop();

        if (!bFound) {
          $("#rv-pos-table").before("<h2 id='deleteMePO'>Purchase Order not found.<h2>");
        };
      }
    });
  }; // getReqs

  function showMyApprovals() {
    localData.viewReqsData = {};
    localData.viewReqsData.queryString = "h_inq_app_status=Pending&h_approval_user=" + getCookie("UserName");
    localData.viewReqsData.title = "Pending Approval";
    localData.viewReqsData.action = SHOW_FIRST;
    localData.viewReqsData.lastRowid = "";

    changePage("#viewReqsPage");
    if (getActivePage().attr("id") == "viewReqsPage") {
      getReqs();    
      if ($(".menuPanel", getActivePage()).is(":visible")) {
        $(".menuPanel", getActivePage()).panel("close");
      }
    }
    
  }

  function showMyRequisitions() {
    localData.viewReqsData = {};
    localData.viewReqsData.queryString = "h_create_user="+localStorage.getItem("name");
    localData.viewReqsData.title = "My Requisitions";
    localData.viewReqsData.action = SHOW_FIRST;
    localData.viewReqsData.lastRowid = "";

    changePage("#viewReqsPage");
    if (getActivePage().attr("id") == "viewReqsPage") {
      getReqs();    
      if ($(".menuPanel", getActivePage()).is(":visible")) {
        $(".menuPanel", getActivePage()).panel("close");
      }
    }
  }
  
  function showPunchouts() {
    $("#ulPunchout").empty();
    $.each(initData.Punchout, function(i) {
      var supplier = initData.Punchout[i];
      var $li =
        $("<li data-icon='shop'>" +
        "<a rel='external' href='" + myURL + "punchout.p?h_token=" + sToken + "&h_supplier_code=" + supplier.Code + "'>" + 
          supplier.Desc +
        "<h2>" + supplier.Name + "</h2>" +
        "<p>" + supplier.Code + "</p>" +
        "</a>" +
        "</li>");
      $li.find("img").prop("height", "100");
      $("#ulPunchout").append($li).trigger("create");
    });
    
    $("#ulPunchout").listview("refresh");
  }
  
  $(document).on("pageinit", "#viewSearchPage", function () {
    $("#h_inq_supplier_ac").on("listviewbeforefilter", supplierAutoComplete);
    $("#h_inq_buyer_ac").on("listviewbeforefilter", userAutoComplete);
    $("#h_create_user_ac").on("listviewbeforefilter", userAutoComplete);
    $("#h_approval_user_ac").on("listviewbeforefilter", userAutoComplete);
    $("#h_poinq_supplier_ac").on("listviewbeforefilter", supplierAutoComplete);
    $("#h_inq_item_ac").on("listviewbeforefilter", itemInqAutoComplete);
    $("#h_inq_unspsc_ac").on("listviewbeforefilter", unspscInqAutoComplete);
    $("#h_inq_project_ac").on("listviewbeforefilter", projectAutoComplete);
  });

  $(document).on("pageinit", "#viewPOSearchPage", function () {
    $("#h_poinq_supplier_ac").on("listviewbeforefilter", supplierAutoComplete);
  });

  $(document).on({
    ajaxStart: function() {$.mobile.loading( "show", {
      text: "foo",
      textVisible: false,
      html: ""
    });
    },
     ajaxStop: function() {   $.mobile.loading( "hide", {
       text: "foo",
       textVisible: false,
       html: ""
     });
   }    
  }); // document.on
  
  // scroll collapsible to top 
  $(document).on("collapsibleexpand", "[data-role=collapsible]", function (event) {
    //event.stopPropagation();
    event.stopImmediatePropagation();
    var position = $(this).offset().top;
    //$.mobile.silentScroll(position - 100);
    scrollToTop(position - $(".jqm-header", getActivePage()).height() - 10);
  });
  
  //localStorage.removeItem('localData');
  
  // Event Order
  // https://jqmtricks.wordpress.com/2014/03/26/jquery-mobile-page-events/
  
  $(document).on("pagebeforechange", function (e, data) {
  
    /* just want this done on login */
    if (!bDone && data.options.fromPage === undefined) {

      /* check token */
      if (sToken >= "") {
        // FRANK DO AN AJAX CALL TO SOMETHING THAT SHOULD ALWAYS RETURN SUCCESSFULLY.
        // IF IT DOESN'T THEN FORCE RE-LOGIN
      }
      
      localData = localStorage.getObject("localData");
      window.onunload = function() { saveSettings(); }

      $("#viewSearchSearchButton").bind("vclick", function(e) {
         showQuickResults();
         e.preventDefault();
      });    

      $("#viewSearchCancelButton").bind("vclick", function(e) {
         clearSearch();   
         e.preventDefault();
      })    

      $("#POSearchSearchButton").bind("vclick", function(e) {
         showPOResults();   
         e.preventDefault();
      });    

      $("#POSearchCancelButton").bind("vclick", function(e) {
         clearPOSearch();   
         e.preventDefault();
      });      
      
      $("#firstReqsButton").bind("vclick", function(e) {
        localData.viewReqsData.action = SHOW_FIRST;
        localData.viewReqsData.lastRowid = "";
        getReqs();
        e.preventDefault();
      });
      
      $("#nextReqsButton").bind("vclick", function(e) {
        localData.viewReqsData.action = SHOW_NEXT;
        getReqs();
        e.preventDefault();
      }); 
  
      $("#firstPOsButton").bind("vclick", function(e) {
        localData.viewPOsData.action = "f";
        localData.viewPOsData.rowids = "";
        getPOs();
        e.preventDefault();
      });
      
      $("#nextPOsButton").bind("vclick", function(e) {
        localData.viewPOsData.action = "n";
        getPOs();
        e.preventDefault();
      }); 
      
      $("#h_approval_attempts_picker").bind( "change", function(event, ui) {
        showApprovals($(this).val());
      });
  
      $("#approveButton").bind("vclick", function(e) {
        approveReq(true);
        e.preventDefault();
      });
  
      $("#rejectButton").bind("vclick", function(e) {
        approveReq(false);
        e.preventDefault();
      });
  
      $("#saveOOF").bind("vclick", function(e) {
        if ($("#h_delegate").val() == "") {
          showErrorMessage("Please select a delegate.");
          e.preventDefault();
          return;
        }
        saveOOF(); 
        e.preventDefault();
       }); 
  
      $("#clearOOF").bind("vclick", function(e) {
        clearOOF(); 
        e.preventDefault();
       }); 
  
      if (localData.viewReqsData == undefined) {
        localData.viewReqsData = {};
      }
      localData.viewReqsData.action = SHOW_FIRST;
  
      if (localData.viewPOsData == undefined) {
        localData.viewPOsData = {};
      }
      localData.viewPOsData.action = "f";
      
      bDone = true;
      if (sShowReq > "") {
        localData.viewReqData = {};
        localData.viewReqData.Domain = sDomain;
        localData.viewReqData.reqNbr = sShowReq;
        
        changePage("#viewReqPage");
        e.preventDefault(); /* this will stop showing first page */
      };
      
      if (redirectTo > "") {
        changePage(redirectTo);
        e.preventDefault();
        redirectTo = "";
      }
    }
  }); // pageBeforeChange
  
  $(document).bind('pagecreate', function(event) {
    panelCounter++;
    var activePage = $(event.target);
    
    if (activePage.attr("data-dialog") == "true") {
       return;
    }
  
    // Scroll to top image at bottom right of every page
    activePage.append('<a data-role="button" class="top-link" data-iconpos="notext" data-icon="arrow-u" href="#top">Top</a>');
    $('.top-link', activePage).scrollToTop();
    $('.top-link', activePage).bind("vclick", function(e) {
      scrollToTop();
      $(this).hide();
      e.preventDefault();
    });
  
    activePage.addClass("ui-responsive-panel");
    var $newPanel = $Panel.clone();
    var $newHeader = $Header.clone();

    
    if (activePage.attr("id") == "viewReqPage") {
      $newHeader.append($("#rvTabs"));
    }
    else
    if (activePage.attr("id") == "viewSearchPage") {
      $newHeader.append($("#rvSearchTabs"));
    }
  
    var sId = "idPanel" + panelCounter;
    $newPanel.attr("id", sId);
  if(activePage.attr("id") != "LoginPage") {
    if(activePage.attr("id") != "serverSettingsPage"){
      if(activePage.attr("id") != "touchIDOptionPage"){
      activePage.append($newPanel);
    getMenu($newPanel);

    if ($newHeader.find(".jqm-header-nav-bar ul").children().length == 1) {
      $newHeader.find(".jqm-header-nav-bar").remove();
    }
  
    $(".backBtn", $newHeader).bind("vclick", function(e) {
      window.history.back();
      e.preventDefault();
    })
    
    $newPanel.panel().trigger("create");

    $(".jqm-navmenu-panel ul" ).listview();
  
    activePage.append($newHeader).trigger("create");
}
}
}
    $(".pendingMyApproval", activePage).bind("vclick", function(e) {
      showMyApprovals();
      return false;
    });
    
    $(".myRequisitions", activePage).bind("vclick", function(e) {
      showMyRequisitions();
      return false;
    });

    activePage.append(footer).trigger("create");
    
    $(".menuLink", activePage).attr("href", "#" + sId);
  
    $('.jqm-list', $newPanel).children('li').find('a').bind('vclick', function(e) {
      if ($(this).attr("href") == "#viewReqsPage") {
        localData.viewReqsData = {};
        localData.viewReqsData.queryString = "h_req_my_views=:" + $(this).attr('data-name');
        localData.viewReqsData.title = $(this).text();
        localData.viewReqsData.action = SHOW_FIRST;
        localData.viewReqsData.lastRowid = "";
        
        if ($.mobile.activePage.attr("id") == "viewReqsPage") {
          getReqs();
          $("[data-role=panel]").panel("close");
        }
      }
    });
    
    if (activePage.attr("id") == "viewSearchPage") {
      fillListsSearchPage();
    }
    
  }); // pageCreate
function homePage_pushnotication(){
    if(isloggedIn && fromPushNotification){
        changePage("#pushNotification");
        fromPushNotification=false;
    }
    else{
        changePage("#homePage");

    }
}
  $(document).on( "pagecontainerbeforeshow", function ( event, ui ) {

    switch (getActivePage().attr("id")) {
      case "homePage":
        $(".backBtn", "#homePage").hide();

$("[data-role=panel]").panel().enhanceWithin();
$("div[role='application']").addClass("sliderItouch");
  //$("#flip-1").on("change", flipChanged);

$("#pushSettings").click(function(){

 changePage("#pushNotification");
  
});
/*if(fromExternalSource){
changePage("#pushNotification");

}*/
//if(isloggedIn && fromPushNotification){
//changePage("#pushNotification");
//fromPushNotification=false;
//
//}

        break;
      case "viewSearchPage":
        setHeader("Requisition Inquiry");
        break;
      case "viewPOSearchPage":
        setHeader("PO Inquiry");
        break;
      case "viewOOFPage":
        setHeader("Out of Office");
        getOOF();
        break;
      case "viewReqsPage":
        getReqs();
        break;
      case "viewReqPage":
        getReq();
        break;
      case "viewItemPage":
        getItem();
        break;
      case "viewContactPage":
        getContact();
        break;
      case "viewGroupPage":
        getGroup();
        break;
      case "viewUserPage":
        getUser();
        break;
      case "viewPOsPage":
        getPOs();
        break;
      case "viewPunchoutsPage":
        setHeader("Supplier Punchouts");
        showPunchouts();
        break;
      case "pushNotification":
        $("#flip-2").on("change", pushSettings);
        loadData();
        break;
    }
  }); // pageContainerBeforeShow


function userCapturePhoto(flag){
     localStorage.setItem("flag",flag);
    navigator.notification.confirm("Upload File Using",onConfirm,"File Upload",["Camera","Gallery"]);
    
}

function onConfirm(buttonIndex) {
    if(buttonIndex==1){
        navigator.camera.getPicture(userOnSuccess, cameraOnFail, { quality: 100, allowEdit: false,
                                    destinationType: Camera.DestinationType.FILE_URI,cameraDirection:Camera.Direction.BACK,targetWidth: 512,targetHeight: 512
                                    });
    }else{
        navigator.camera.getPicture(userOnSuccess, cameraOnFail, { quality: 100, allowEdit: false,
                                    destinationType: Camera.DestinationType.FILE_URI,sourceType:Camera.PictureSourceType.SAVEDPHOTOALBUM,targetWidth: 512,targetHeight: 512
                                    });
    }
    
}


function userOnSuccess(imageURI){
    uploadPhoto(imageURI);
    if(localStorage.getItem("flag")==0){
    //    alert("1");
    var smallImage = document.getElementById('PictureArea');
    }
    else{
       // alert("2");
        var smallImage = document.getElementById('PictureArealine');
   }
    navigator.notification.confirm("Your attachment has been uploaded successfully.",getReq,"Attachment Upload",["Ok"]);
  //  alert("smallImage");
   // smallImage.style.display = 'block';
   // smallImage.src =imageURI;
   
    
}

function onAttachmentConfirm(){
  $.mobile.loading( "show", {
                     text: "Fetching Attachments",
                     textVisible: true,
                     html: ""
                     });

    $(function() {
     // $("#button").click(function() {
                         setTimeout(getReq, 4000);
                        // });
      
      });
    //getItem();
  //  getReq();
//     if(localStorage.getItem("flag")==0){
//       //  alert("getReq");
//    getReq();
//     }
//     else{
//       //  alert("getItem");
//         getItem();
//     }
}


function cameraOnFail(message) {
    showAlert(message,"iPurchase");
}


function uploadPhoto(imageURI) {
  //alert("fd"+imageURI);
   // console.log(myURL+"upload.p?h_req_nbr=&h_line_nbr&h_internal=true=&h_token"+sToken);
    i++;
   var options = new FileUploadOptions();
    if(localStorage.getItem("flag")==0){
    options.fileKey="h_filename";
        
    }
    else{
         options.fileKey="h_line_filename";
    }
    options.fileName=imageURI.substr(imageURI.lastIndexOf('/')+1);
    if(device.platform=="Android"){
        var androipath=options.fileName.split('?');
        options.fileName=androipath[0];
        
    }
//    options.fileName=options.fileName+"-"+sToken+i;
   
    options.fileName=sToken+i+"-"+options.fileName;
    
    
//alert(options.fileName);
    options.mimeType="image/jpeg";
    var params = new Object();
    options.params = params;
    options.chunkedMode = false;
    var ft = new FileTransfer();
ft.upload(imageURI,myURL+"upload.p?h_req_nbr="+localStorage.getItem("req_nbr")+"&h_line_nbr="+localStorage.getItem("flag")+"&h_internal=true=&h_token"+sToken, win, fail, options);
    
}

function win(r) {
    
    console.log("Code = " + r.responseCode);
    console.log("Response = " + r.response);
    console.log("Sent = " + r.bytesSent);
 //showAlert(r.response);
   // alert(r.responseCode);
}

function fail(error) {
    showAlert("An error has occurred: Code = " + error.code,"iPurchase");
}

function loadData(){

  db = openDatabase('ISS.db', '1.0', 'Test DB',  2* 1024 * 1024);
  db.transaction(function (tx) {  
   

      tx.executeSql("SELECT * from pushDatas", [], function(tx, res) {
                 $('#listofevents').html("");                            
        var len = res.rows.length, i;
                //loop around each event record in the database
                for (i = 0; i < len; i++) {
                    var EventRecord = res.rows.item(i);

                    //create event list item list item. 
                    var individualEvent = '';
                    individualEvent = '<li>';
                    individualEvent += '<h3>' + EventRecord.additionalData + '</h3>';
                    individualEvent += '<p>' + EventRecord.message + '</p>';
                    individualEvent += '</li>';

                 
                    $('#listofevents').append(individualEvent);
                    $('#listofevents').listview('refresh');
                } //end for loop



                                                });
  });



}

function onConfirmlogout(buttonIndex) {
    if(buttonIndex==1){
        mobilelogoff();
      
          }

    
}

function mobilelogoff() {

        $.ajax({
               url: myURL + "moblogoff.p?h_token=" + sToken,
               cache: false,
               async: false,
               datatype: "json",
               success: function (data) {
               //initData = data.dataset;
               //alert(JSON.stringify(data.dataset));
               localStorage.removeItem("keepMeLoggedIn");
               localStorage.removeItem("logInUserName");
               localStorage.removeItem("logInDomain");
               localStorage.removeItem("h_lang");
                localStorage.setItem("touchidoption","false");
               changePage("#LoginPage");
              
               }
               });


}
function logOff(){

     navigator.notification.confirm("Are you sure you want to logoff?",onConfirmlogout,"iPurchase",["Ok","Cancel"]);
  

}

//http://demo.issgroup.net/scripts/cgiip.exe/WService=iPurchase/moblogoff.p?h_token=JVksxhDlovIhcAeK000725095034817160saaetielcAadjQbkksBlNkimfbZainKSpcdfbbTiracckUO

//myURL + "mobinit.p?h_token=" + sToken

//var myURL = 'upload.p?h_req_nbr=' + $("#h_req_nbr").val() + "&h_line_nbr=" +
//"&h_internal=true" + '&h_token=' + $("#h_token").val();