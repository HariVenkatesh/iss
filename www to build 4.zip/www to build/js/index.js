var webServiceUrl = "http://demo.issgroup.net/scripts/cgiip.exe/WService=iPurchase/";
var fromExternalSource=false;
var fromPushNotification=false;
var isloggedIn=false;
var locationfromexteranal="";
var push={};
var domainList=[];
var domainArray=[];
var selectedDomain="";
var selectedlang="";
var token="";
var pushToken="";
var pushNotification;

//Device ready
var pictureSource;   // picture source
var destinationType;


document.addEventListener("deviceready", onDeviceReady, false);

function onDeviceReady(){
    StatusBar.backgroundColorByHexString('#1D1D1D');
    pictureSource=navigator.camera.PictureSourceType;
    destinationType=navigator.camera.DestinationType;
    if(localStorage.getItem("webServiceUrlOption")=="undefined" || localStorage.getItem("webServiceUrlOption")==null){
    localStorage.setItem("webServiceUrlOption","false");
    localStorage.setItem("webServiceUrl","http://demo.issgroup.net/scripts/cgiip.exe/WService=iPurchase/");
    }
    if(localStorage.getItem("touchidoption")=="true"){
        touchIDLogin();
    }
  
}

//$("#LoginPage").ready(function(){
$(document).on("pageshow","#LoginPage",function(){
                   //   alert("testready");
                      Apploadingicon();
                      
                 getDomain();getlanguage();
                
                      $("[data-role=panel]").panel().enhanceWithin();
                      $("div[role='application']").addClass("sliderItouch");

                      if(localStorage.getItem("keepMeLoggedIn")=="true"){
                      
                      $("#stay_logged_in").attr("checked",true).checkboxradio("refresh");
                      
                      login(2);
                      }else{
                      $("#stay_logged_in").attr("checked",false).checkboxradio("refresh");
                      }
                      
                      
                      $("#iTouchSettings").click(function(){
                                                 
                                                 changePage("#touchIDOptionPage");
                                                 
                                                 });
                      $('#Domain').on('change', function(e) {
                                      selectedDomain=e.target.options[e.target.selectedIndex].text;
                                      localStorage.setItem("logInDomain",selectedDomain);
                                      });
                      $('#h_language').on('change', function(e) {
                                          selectedlang=e.target.options[e.target.selectedIndex].value;
                                          localStorage.setItem("h_lang",selectedlang);
                                          });
                      $("#stay_logged_in").bind( "change", function(event, ui) {
                                                
                                                if ($(this).is(':checked')) {
                                                
                                                localStorage.setItem("keepMeLoggedIn",$(this).is(':checked'));
                                                localStorage.setItem("logInUserName",$("#Username").val());
                                                localStorage.setItem("logInPassWord",$("#Password").val());
                                                localStorage.setItem("logInDomain",selectedDomain);
                                                localStorage.setItem("h_lang",selectedlang);
                                                
                                                }
                                                
                                                
                                                });
                      $("#serverSettings").click(function(){
                                                 
                                                 changePage("#serverSettingsPage");
                                                 
                                                 });
  
//               if(localStorage.getItem("touchidoption")=="true"){
//               touchIDLogin();
//               }
               
             
               
                      hideLoadingIcon();
                    
               });

$(document).on("pagecreate","#LoginPage",function(){
$("#touchpageback").click(function(){
                         // alert(1);
                          if(localStorage.getItem("touchidoption")=="true"){
                          touchIDLogin();
                          }
                          else{
                          changePage("#LoginPage");
                          }
                          });
               });
//function touchpageback(){
//    alert("onlcick");
//     if(localStorage.getItem("touchidoption")=="true"){
//    touchIDLogin();
//      }
//}
function successHandler (result) {
    //alert('result = ' + result);
}

// result contains any error description text returned from the plugin call
function errorHandler (error) {
    showAlert(error, "iPurchase");
}

function onNotificationAPN (event) {
    
 //   alert(JSON.stringify(event));
 //   alert(event.message + "title" + event.title);
    showToastAlert('New Notification Received');
  fromPushNotification=true;
    
    db = openDatabase('ISS.db', '1.0', 'Test DB',  2* 1024 * 1024);
    db.transaction(function (tx) {
                   tx.executeSql("CREATE TABLE IF NOT EXISTS pushDatas (message  TEXT,additionalData TEXT)");
                   
                   tx.executeSql("INSERT INTO pushDatas (message,additionalData) VALUES(?,?)", [event.payload,event.alert], function(tx, res) {
                                 
                                 if(isloggedIn){
                               changePage("#pushNotification");

                                 }
                                 });
                   });
    
}

function tokenHandler (result) {
  
    localStorage.setItem("pushToken", result);
}


function onNotification(e) {
    
    switch( e.event )
    {
        case 'registered':
            if ( e.regid.length > 0 )
            {
                localStorage.setItem("pushToken",e.regid);
            }
            break;
            
        case 'message':
            if ( e.foreground )
            {
                showToastAlert('New Notification Received');
                fromPushNotification=true;
                db = openDatabase('ISS.db', '1.0', 'Test DB',  2* 1024 * 1024);
                db.transaction(function (tx) {
                               tx.executeSql("CREATE TABLE IF NOT EXISTS pushDatas (message  TEXT,additionalData TEXT)");
                               
                               tx.executeSql("INSERT INTO pushDatas (message,additionalData) VALUES(?,?)", [e.payload.message,e.payload.title], function(tx, res) {
                                             
                                             if(isloggedIn){
                                             changePage("#pushNotification");
                                             }
                                             });
                               });

                
            }
            else
            {  // otherwise we were launched because the user touched a notification in the notification tray.
                if ( e.coldstart )
                {

                }
                else
                {
                    
                }
            }
            
        break;
            
        case 'error':
            showAlert(e.msg,"iPurchase");
            break;
            
        default:
            break;
    }
}



function customServerURL(){


 $("#serverUrl").val(localStorage.getItem("webServiceUrl"));

  if(localStorage.getItem("webServiceUrlOption")=="true"){

    $("#serverURLFlip").val('On').slider('refresh');

 //localStorage.setItem("webServiceUrl",$("#serverUrl").val());

  }else{
            //localStorage.setItem("webServiceUrl","http://demo.issgroup.net/scripts/cgiip.exe/WService=iPurchase/");

    $("#serverURLFlip").val('Off').slider('refresh');

  }
}


function successCallback(){
   // alert("won");
  touchid.authenticate(successCallbackfromtouch, failureCallback);

}

function notSupportedCallback(){

}

function successCallbackfromtouch(){

 login(1);
     // window.location.href = 'index.html';
   }

   function failureCallback(){

    showAlert("TouchID Failed.!","iPurchase");
     //$("#touchIDFlip").val("Off").slider("refresh");
       changePage("#LoginPage");
  }

//camera integration

/* ChangePage function*/

function changePage(pagename) {
 console.log("index");
  $.mobile.changePage(pagename, {
    transition: "none"
    
  });

}


/*Show App Loading Image From Respective Function*/
function Apploadingicon() {

  $.mobile.loading("show", {
   text: "Loading...",
   textVisible: true,
   theme: "b",
   html: ""
 });
}

/*Hide App Loading Image From Respective Function*/
function hideLoadingIcon() {
  $.mobile.loading("hide");
}

var isiOS = navigator.userAgent.match('iPad') || navigator.userAgent.match('iPhone') || navigator.userAgent.match('iPod');
if (isiOS) {
    function handleOpenURL(url) {
        fromExternalSource = true;
        
        locationfromexteranal = "ipurchase://";
        if (url != null) {
            localStorage.setItem("ShowReq","1");
            // Here you need to first split with "?" then later with "&"
            var link = url.split("?");
            var keysPair = link[1].split("&");
            // use as per your need
            var showReqValue = keysPair[3].split("=");
            localStorage.setItem("showReqValue",showReqValue[1]);
            var DomainValue = keysPair[4].split("=");
           //  alert(DomainValue[0]);
            // alert(DomainValue[1]);
            var showDomainValue = DomainValue[1].split(":");
            // alert(showDomainValue[0]);
            // alert(showDomainValue[1]);
         //   localStorage.setItem("DomainValue",showDomainValue[0]);
            localStorage.setItem("logInDomain",showDomainValue[0]);
            
        }
        //changePage("#viewSearchPage");
        
        $(".searchLink").trigger('click');
    }
}
/*Check NetConnection Before calling Web Service*/

function checkConnection() {

  var networkState = navigator.connection.type;
  var states = {};
  states[Connection.UNKNOWN] = 'Unknown connection';
  states[Connection.ETHERNET] = 'Ethernet connection';
  states[Connection.WIFI] = 'WiFi connection';
  states[Connection.CELL_2G] = 'Cell 2G connection';
  states[Connection.CELL_3G] = 'Cell 3G connection';
  states[Connection.CELL_4G] = 'Cell 4G connection';
  states[Connection.NONE] = 'No network connection';
  if (states[networkState] == 'No network connection') {
    return false;
  } else {
    return true;
  }
}

/*Exception Handling Block*/
function errorHandling(originalCode) {
  try {
    originalCode();
  } catch (err) {
    showAlert(err.message,"iPurchase");
  }
}

/*Show alert Box Using From Respective Function*/

function showAlert(alertmessage, title, callBack_func) {
  if (callBack_func) {
    navigator.notification.alert(alertmessage, callBack_func, title, "OK");
  } else {
    navigator.notification.alert(alertmessage, false, title, "OK");
  }
}

/* login Function */

function iPurchaseWebService(requestType, methodName, param, callBack) {

  errorHandling(function() {
    Apploadingicon();
    if (checkConnection()) {
      $.ajax({
       type: "" + requestType + "",
       url: webServiceUrl + "" + methodName + "",
       data: param,
       success: function(msg) {
         callBack(msg);
       },
       error: function(xhr) {
         //console.log("sdf" + JSON.stringify(xhr));
         showAlert("DB connection error", "iPurchase");
         hideLoadingIcon();
       }
     });
    } else {
      showAlert("Please check internet connection.", "iPurchase");
      hideLoadingIcon();
    }
  });
}

//Currentlocation

function geolocationSuccess(position) {
  localStorage.setItem("long", position.coords.longitude);
  localStorage.setItem("lat", position.coords.Latitude);
//      window.location.href = "index.html";

}

// onError Callback receives a PositionError

function geolocationError(error) {
  //alert('code: '    + error.code    + '\n' +
   // 'message: ' + error.message + '\n');
     showAlert("Please turn on your location settings.", "iPurchase");
}


/*-- Function Call Based On Page ID --*/

$(document).on("pagecontainershow", function(event, ui) {

 var activePage = $.mobile.pageContainer.pagecontainer("getActivePage");
          //     alert("id");
 activePageName = activePage.attr('id');
               if(activePageName=="pushNotification"){
               $(".backBtn").hide();
               }
               else{
               $(".backBtn").show();
               }
 switch (activePage.attr('id')) {

case 'homePage':
getAppStatus();
break;
  case 'touchIDOptionPage':
  checkTouchIDEnabled();

  $("#touchIDFlip").on("change", function (event) {
   if($("#touchIDFlip").val()=="On"){
     $("#popupLogin").popup("open");
   }else if($("#touchIDFlip").val()=="Off"){
    // localStorage.setItem("logInUserName","");
    // localStorage.setItem("logInPassWord","");
  }
});
//  $(".backbtn").click(function(){
//
//   changePage("#LoginPage");
//
// });
               if(localStorage.getItem("touchidoption")=="false"){
               $("#touchIDFlip").val("Off").slider("refresh");
               }
  break;
  case 'serverSettingsPage':
     customServerURL();


     $( "#serverUrl" ).change(function() {
  // Check input( $( this ).val() ) for validity here
  if($("#serverURLFlip").val()=="On")
      localStorage.setItem("webServiceUrl",$("#serverUrl").val());
    else
       localStorage.setItem("webServiceUrl","http://demo.issgroup.net/scripts/cgiip.exe/WService=iPurchase/");

});

      $(".backbtn").click(function(){

   changePage("#LoginPage");

 });
     $("#serverURLFlip").on("change", enableServerCustomUrl);
 
  break;
}
});

/*-- Pagecontainershow End --*/




$("#serverURLFlip").on("change", enableServerCustomUrl);

function enableServerCustomUrl(e) {
  var id = this.id,
  value = this.value;

  if(value=="On"){
    localStorage.setItem("webServiceUrl",$("#serverUrl").val());
    localStorage.setItem("webServiceUrlOption",true);

  }else{
   localStorage.setItem("webServiceUrl","http://demo.issgroup.net/scripts/cgiip.exe/WService=iPurchase/");
   localStorage.setItem("webServiceUrlOption",false);
 }

}

function getAppStatus(){
    console.log("getapp")
    if(localStorage.getItem("ShowReq")=="1"){
        //  alert("getAppStatus");
        //  localData.viewReqData.Domain = localStorage.getItem("showReqValue");
        //  localData.viewReqData.reqNbr = localStorage.getItem("DomainValue");
        changePage("#viewReqPage");
    }
    else{
        console.log("else");
        changePage("#homePage");
    }
    
}
function loginValidation(flag){

    if($("#Username").val()=="" || $("#Username").val()==null){
        showAlert("Username is required","iPurchase");
    }
    else if($("#Domain").val()=="" || $("#Domain").val()==null){
         showAlert("Domain is required","iPurchase");
    }
    else if($("#h_language").val()=="" || $("#h_language").val()==null){
         showAlert("Language is required","iPurchase");
    }
    else{
        login(flag);
    }
}

function login(flag){
   // alert("flag"+1);
    Apploadingicon();
    var deviceType = (navigator.userAgent.match(/iPad/i))  == "iPad" ? "ios" : (navigator.userAgent.match(/iPhone/i))  == "iPhone" ? "ios" : (navigator.userAgent.match(/Android/i)) == "Android" ? "android" : (navigator.userAgent.match(/BlackBerry/i)) == "BlackBerry" ? "BlackBerry" : "null";

    localStorage.setItem("webServiceUrl",webServiceUrl);
    if(flag==2){
        if(localStorage.getItem("logInPassWord")==null){
           localStorage.setItem("logInPassWord","");
        }
        websiteURL=localStorage.getItem("webServiceUrl")+"login.p?autolog=&Username="+localStorage.getItem("logInUserName")+"&password="+localStorage.getItem("logInPassWord")+"&language=Language&Domain="+localStorage.getItem("logInDomain")+"&h_language="+localStorage.getItem("h_lang")+"&h_file=&changepassword=&Interface=ipurchase&deviceToken="+ localStorage.getItem("pushToken")+"&platform="+deviceType;

    
        $.ajax({
               type: "GET",
               url:websiteURL,
               dataType:"json",
               success: function(msg) {
               var obj =msg.Response[0];
               if(obj.Valid){
               localStorage.setItem("logInDomain",selectedDomain);
               localStorage.setItem("h_lang",selectedlang);
               localStorage.setItem("Token",obj.Token);
               localStorage.setItem("name",$('#Username').val());
               
               sDomain=obj.Domain;
               sToken=obj.Token;
               //alert(sToken);
               var URLobject = {showReqObject:localStorage.getItem("showReqValue"), domainObject:localStorage.getItem("DomainValue"), showTokenValue:obj.Token};
               //alert(U/Users/hari/Desktop/ISS/iPurchase/platforms/ios/www/js/index.jsRLobject);
               localStorage.setObject("showTokenValue",URLobject.showTokenValue);
               
               
               localStorage.setObject("showReqValue",URLobject.showReqObject);
               //  alert(localStorage.getObject("showReqValue"));
               localStorage.setObject("DomainValue",URLobject.domainObject);
               navigator.geolocation.getCurrentPosition(geolocationSuccess,
                                                        geolocationError,
                                                        {maximumAge: 3000, timeout: 5000, enableHighAccuracy: true });
               //if(localStorage.getItem("long")!=""){
               isloggedIn=true;
               changePage("#homePage");
               }
               else{
               showAlert(obj.InvalidMessage,"iPurchase");
               }
               
               // window.location.href = 'index.html#homePage';
               //}
               hideLoadingIcon();
               },
               error: function(xhr) {
               showAlert("Please check your login settings and try again later","iPurchase");
               hideLoadingIcon();
               }
               });

    //  $("#Username").val()
    }
//if(localStorage.getItem("logInUserName")==null){
    else if(flag==1){
        if(localStorage.getItem("logInPassWord")==null){
            localStorage.setItem("logInPassWord","");
        }
        if(localStorage.getItem("logInDomain")==null){
            localStorage.setItem("logInDomain","");
        }
        websiteURL=localStorage.getItem("webServiceUrl")+"login.p?autolog=&Username="+localStorage.getItem("logInUserName")+"&password="+localStorage.getItem("logInPassWord")+"&language=Language&Domain="+localStorage.getItem("logInDomain")+"&h_language="+localStorage.getItem("h_lang")+"&h_file=&changepassword=&Interface=ipurchase&deviceToken="+ localStorage.getItem("pushToken")+"&platform="+deviceType;
        
        $.ajax({
               type: "GET",
               url:websiteURL,
               dataType:"json",
               success: function(msg) {
               // alert(JSON.stringify(msg));
               var obj =msg.Response[0];
               
               if(obj.Valid){
               //alert("msg 1"+obj.Valid);
               
               localStorage.setItem("logInDomain",selectedDomain);
               // localStorage.setItem("h_lang",selectedlang);
               localStorage.setItem("Token",obj.Token);
               localStorage.setItem("name",$('#Username').val());
               sDomain=obj.Domain;
               sToken=obj.Token;
               //alert(sToken);
               var URLobject = {showReqObject:localStorage.getItem("showReqValue"), domainObject:localStorage.getItem("DomainValue"), showTokenValue:obj.Token};
               //alert(URLobject);
               localStorage.setObject("showTokenValue",URLobject.showTokenValue);
               
               
               localStorage.setObject("showReqValue",URLobject.showReqObject);
               //  alert(localStorage.getObject("showReqValue"));
               localStorage.setObject("DomainValue",URLobject.domainObject);
               navigator.geolocation.getCurrentPosition(geolocationSuccess,
                                                        geolocationError,
                                                        {maximumAge: 3000, timeout: 5000, enableHighAccuracy: true });
               //if(localStorage.getItem("long")!=""){
               isloggedIn=true;
               changePage("#homePage");

               }
               else{
               showAlert(obj.InvalidMessage,"iPurchase");
               }
               
               // window.location.href = 'index.html#homePage';
               //}
               hideLoadingIcon();
               },
               error: function(xhr) {
               showAlert("Please check your login settings and try again later","iPurchase");
               hideLoadingIcon();
               }
               });

        
    }
    else{

  localStorage.setItem("logInUserName",$("#Username").val());
  localStorage.setItem("logInPassWord",$("#Password").val());
  localStorage.setItem("logInDomain",$("#Domain").val());
  localStorage.setItem("h_lang",$("#h_language").val());
        
        websiteURL=localStorage.getItem("webServiceUrl")+"login.p?autolog=&Username="+localStorage.getItem("logInUserName")+"&password="+localStorage.getItem("logInPassWord")+"&language=Language&Domain="+localStorage.getItem("logInDomain")+"&h_language="+localStorage.getItem("h_lang")+"&h_file=&changepassword=&Interface=ipurchase&deviceToken="+ localStorage.getItem("pushToken")+"&platform="+deviceType;
    
  $.ajax({
   type: "GET",
   url:websiteURL,
   dataType:"json",
   success: function(msg) {
        // alert(JSON.stringify(msg));
     var obj =msg.Response[0];
         
         if(obj.Valid){
         //alert("msg 1"+obj.Valid);
         
         localStorage.setItem("logInDomain",selectedDomain);
        // localStorage.setItem("h_lang",selectedlang);
         localStorage.setItem("Token",obj.Token);
         localStorage.setItem("name",$('#Username').val());
         sDomain=obj.Domain;
         sToken=obj.Token;
            //alert(sToken);
         var URLobject = {showReqObject:localStorage.getItem("showReqValue"), domainObject:localStorage.getItem("DomainValue"), showTokenValue:obj.Token};
          //alert(URLobject);
         localStorage.setObject("showTokenValue",URLobject.showTokenValue);
         
         
         localStorage.setObject("showReqValue",URLobject.showReqObject);
         //  alert(localStorage.getObject("showReqValue"));
         localStorage.setObject("DomainValue",URLobject.domainObject);
         navigator.geolocation.getCurrentPosition(geolocationSuccess,
                                                  geolocationError,
                                                  {maximumAge: 3000, timeout: 5000, enableHighAccuracy: true });
         //if(localStorage.getItem("long")!=""){
         isloggedIn=true;
         changePage("#homePage");
         }
         else{
         showAlert(obj.InvalidMessage,"iPurchase");
         }
       
       // window.location.href = 'index.html#homePage';
           //}
         hideLoadingIcon();
         },
         error: function(xhr) {
           showAlert("Please check your login settings and try again later","iPurchase");
           hideLoadingIcon();
         }
       });
    }
  //window.location.href = 'index.html'; //Will take you to xyz.
  }

  function getDomain(){
      Apploadingicon();
      if(localStorage.getItem("logInDomain")!=null){
          var lastDomain=localStorage.getItem("logInDomain");
      }
      else{
          var lastDomain="";
      }
    var domainURL="http://demo.issgroup.net/scripts/cgiip.exe/WService=iPurchase/getsettings2.p?h_settings=ALLOWED_DOMAINS&app=ipurchase&_=1458540828033";

    $.ajax({
     type: "GET",
     url: domainURL,
     dataType:"json",
     success: function(msg) {

      domainVal=msg.dataset.Settings[0].Value;

      domainArray = domainVal.split(',');

      var select = $('#Domain');
      var select_touch = $('#Domain_touch');
      select.html("");
      select_touch.html("");
         var optTempl = '<option value="">Select Domain</option>';            
        select.append(optTempl);
           select_touch.append(optTempl);
      $.each(domainArray, function(index, state) {
        var optTempl = '<option value="'+state+ '">'+state+'</option>';
        select.append(optTempl);
             select_touch.append(optTempl);
              $('#Domain option[value='+lastDomain+']').attr('selected', 'selected');
              $('#Domain_touch option[value='+lastDomain+']').attr('selected', 'selected');
      });
         
      select.selectmenu('refresh');
           select_touch.selectmenu('refresh');
      //select.selectmenu('refresh', true);

       hideLoadingIcon();
           
    },
    error: function(xhr) {
     showAlert("Please check your internet connection and try again later","iPurchase");
     hideLoadingIcon();
   }
 });

    //window.location.href = 'index.html'; //Will take you to xyz.
  }

//function testfunction(){
//    alert("testfunction");
//    console.log($.mobile.changePage("index.html#homePage", { transition: "none", changeHash: false}));
//  $.mobile.changePage("#homePage", { transition: "none", changeHash: false});
//}
  function getlanguage(){
      Apploadingicon();
      if(localStorage.getItem("h_lang")!=null){
          var lastLanguage=localStorage.getItem("h_lang");
      }
      else{
          var lastLanguage=navigator.language;
      }


    var lamgURL="http://demo.issgroup.net/scripts/cgiip.exe/WService=iPurchase/getData.p?h_token=joshua&dsName=xxlang_mstr&outputFormat=json&sort=xxlang_desc&dir=asc";

    $.ajax({
     type: "GET",
     url: lamgURL,
     dataType:"json",
     success: function(msg) {


     // alert(JSON.stringify(msg));
      langArray = msg.dataset.xxlang_mstr;

      var select = $('#h_language');
           var select_touch = $('#h_language_touch');
           select.html("");
           select_touch.html("");
         var optTempl = '<option value="">Select Language</option>';            
        select.append(optTempl);
           select_touch.append(optTempl);
      $.each(langArray, function(index, state) {              
        var optTempl = '<option value="' +state.xxlang_code+ '">'+state.xxlang_desc+'</option>';
             select.append(optTempl);
             select_touch.append(optTempl);
                $('#h_language option[value='+lastLanguage+']').attr('selected', 'selected');
                $('#h_language_touch option[value='+lastLanguage+']').attr('selected', 'selected');
      });
      select.selectmenu('refresh');
      select_touch.selectmenu('refresh');
      //select.selectmenu('refresh', true);

hideLoadingIcon();
    },
    error: function(xhr) {
         showAlert("Please check your internet connection and try again later","iPurchase");
     hideLoadingIcon();
   }
 });

    //window.location.href = 'index.html'; //Will take you to xyz.
  }




  /*Flip Button Functionality Present In Settings Page*/



  /*Log In Functionality*/
  function touchIDLogin(){

    if(localStorage.getItem("touchidoption")=="true"){
     touchid.checkSupport(successCallback, notSupportedCallback);
   }
}



function showToastAlert(msg){
    window.plugins.toast.show(msg,'short', 'top', function(a){
                              console.log('toast success: ' + a);
                              }, function(b){
                              console.log('toast error: ' + b);
                              });
}
//function showAlert(msg){
//    window.plugins.toast.show(msg,'short', 'center', function(a){
//                              console.log('toast success: ' + a);
//                              }, function(b){
//                              console.log('toast error: ' + b);
//                              });
//}

function checkTouchIDEnabled(){
  if((localStorage.getItem("touchidoption")!="")||(localStorage.getItem("touchidoption")!=null)){

    localStorage.setItem("touchidoption","false");
  }else{
    $("#touchIDFlip").val("On").slider("refresh");
    localStorage.setItem("touchidoption","true");
  }
}

function navPage(){
    //alert(1);
    changePage("#LoginPage");
}
function saveCredentials(){
  
        if($("#userName").val()=="" || $("#userName").val()==null){
            showAlert("Username is required","iPurchase");
        }
        else if($("#Domain_touch").val()=="" || $("#Domain_touch").val()==null){
            showAlert("Domain is required","iPurchase");
        }
        else if($("#h_language_touch").val()=="" || $("#h_language_touch").val()==null){
            showAlert("Language is required","iPurchase");
        }
        else{
    
  localStorage.setItem("logInUserName",$("#userName").val());
  localStorage.setItem("logInPassWord",$("#passWord").val());
  localStorage.setItem("logInDomain",$("#Domain_touch").val());
 localStorage.setItem("h_lang",$("#h_language_touch").val());
  localStorage.setItem("touchidoption","true");
    $("#userName").val("");
    $("#passWord").val("");
    $("#Domain_touch").selectmenu("refresh", true);
    $("#h_language_touch").selectmenu("refresh", true);
  $("#popupLogin").popup("close");
    //touchIDLogin();
}
}

function cancelDialog(){
  $("#touchIDFlip").val("Off").slider("refresh");
  $("#popupLogin").popup("close");
   localStorage.setItem("touchidoption","false");

}

//Keep me logged in
function initLogin(){



}
function pushSettings(e) {
  var id = this.id,
  value = this.value;
  showAlert(id + " has been changed! " + value,"iPurchase");


  if(value == "on"){
    push.on('registration', function(data) {
    // data.registrationId
    //alert(JSON.stringify(data));
  });
  }else{
    push.unregister(function() {
    //  alert('successfully unregistered');
    }, function() {
    //  alert('error');
    });
  }


  push.on('error', function(e) {
    // e.message
    //alert(JSON.stringify(e));
  });




}
